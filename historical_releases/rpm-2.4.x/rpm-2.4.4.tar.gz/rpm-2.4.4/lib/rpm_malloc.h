#ifndef H_RPM_MALLOC
#define H_RPM_MALLOC

/* placeholder */

#endif
