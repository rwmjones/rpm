#include "header.h"

void main() {
    Header h;
    char * str;

    h = headerNew();
    headerAddI18NString(h, 1000, "C locale 0", NULL);
    headerAddI18NString(h, 1000, "English 0", "en");

    headerAddI18NString(h, 1001, "English 1", "en");
    headerAddI18NString(h, 1001, "German 1", "de");
    headerAddI18NString(h, 1001, "C locale 1", NULL);

    headerAddI18NString(h, 1000, "German 0", "de");

    headerGetEntry(h, 1000, NULL, &str, NULL);
    printf("got: %s\n", str);
    headerGetEntry(h, 1001, NULL, &str, NULL);
    printf("got: %s\n", str);
}
