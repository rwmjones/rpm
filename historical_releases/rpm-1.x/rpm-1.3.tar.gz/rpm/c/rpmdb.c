#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "misc.h"
#include "rpmdb.h"

static int labelstrlistToLabelList(char * str, int length, 
				   struct rpmdbLabel ** list);
static char * formLabel(struct rpmdbLabel label);

int rpmdbLabelstrToLabel(char * str, int length, struct rpmdbLabel * label) {
    char * chptr;

    label->freeType = RPMDB_FREENAME;
    label->next = NULL;
    label->name = malloc(length + 1);
    if (!label->name) {
	return 1;
    }
    memcpy(label->name, str, length);
    label->name[length] = '\0';

    chptr = label->name;
    while (*chptr != ':') chptr++;
    *chptr = '\0';
    label->version = ++chptr;
    while (*chptr != ':') chptr++;
    *chptr = '\0';
    label->release = chptr + 1;

    /* there might be a path number tagged on to the end of this. if so,
       just truncate this */
    while ((chptr - label->name) < length && *chptr != ':') chptr++;
    if ((chptr - label->name) < length) *chptr = '\0';

    return 0;
}

static int labelstrlistToLabelList(char * str, int length, 
				   struct rpmdbLabel ** list) {
    char * start, * chptr;
    struct rpmdbLabel * head = NULL;
    struct rpmdbLabel * tail, * label;
    
    start = str;
    for (chptr = start; (chptr - str) < length; chptr++) {
	/* spaces following a space get ignored */
	if (*chptr == ' ' && start < chptr) {
	    label = malloc(sizeof(struct rpmdbLabel));
	    if (!label) {
		rpmdbFreeLabelList(head);
		return 1;
	    }
	    if (rpmdbLabelstrToLabel(start, chptr - start, label)) {
		free(label);
		rpmdbFreeLabelList(head);
		return 1;
	    }

	    if (!head) {
		head = label;
		tail = label;
	    } else {
		tail->next = label;
		tail = tail->next;
	    }

	    start = chptr + 1;
	}
    }

    /* a space on the end would break things horribly w/o this test */
    if (start < chptr) {
	label = malloc(sizeof(struct rpmdbLabel));
	if (!label) {
	    rpmdbFreeLabelList(head);
	    return 1;
	}
	if (rpmdbLabelstrToLabel(start, chptr - start, label)) {
	    free(label);
	    rpmdbFreeLabelList(head);
	    return 1;
	}

	if (!head) {
	    head = label;
	    tail = label;
	} else {
	    tail->next = label;
	    tail = tail->next;
	}

	start = chptr + 1;
    }

    *list = head;
    return 0;
}

static char * formLabel(struct rpmdbLabel label) {
    char * ls;

    ls = malloc(strlen(label.name) + strlen(label.release) + 
	 strlen(label.version) + 3);
    if (!ls) return NULL;

    strcpy(ls, label.name);
    strcat(ls, ":");
    strcat(ls, label.version);
    strcat(ls, ":");
    strcat(ls, label.release);

    return ls;
}

int rpmdbOpen(char * prefix, int openFlags, struct rpmdb * rpmdb) {
    unsigned int gdbmFlags = 0;
    char path[255];

    rpmdb->rpmdbError = RPMDB_NONE;

    if (openFlags & RPMDB_READER)
	gdbmFlags |= GDBM_READER;
    if (openFlags & RPMDB_WRITER)
	gdbmFlags |= GDBM_WRITER;

    strcpy(path, prefix);
    strcat(path, "/packages");
    rpmdb->packages = gdbm_open(path, 1024, gdbmFlags, 0644, NULL);
    if (!rpmdb->packages) {
	rpmdb->rpmdbError = RPMDB_GDBM_ERROR;
	rpmdb->gdbmError = gdbm_errno;
	return 1;
    }

    strcpy(path, prefix);
    strcat(path, "/nameidx");
    rpmdb->nameIndex = gdbm_open(path, 1024, gdbmFlags, 0644, NULL);
    if (!rpmdb->nameIndex) {
	rpmdb->rpmdbError = RPMDB_GDBM_ERROR;
	rpmdb->gdbmError = gdbm_errno;
	return 1;
    }

    strcpy(path, prefix);
    strcat(path, "/pathidx");
    rpmdb->pathIndex = gdbm_open(path, 1024, gdbmFlags, 0644, NULL);
    if (!rpmdb->pathIndex) {
	rpmdb->rpmdbError = RPMDB_GDBM_ERROR;
	rpmdb->gdbmError = gdbm_errno;
	return 1;
    }

    return 0;
}

void rpmdbClose(struct rpmdb * rpmdb) {
    gdbm_close(rpmdb->packages);
    gdbm_close(rpmdb->nameIndex);
    gdbm_close(rpmdb->pathIndex);
}

struct rpmdbLabel * rpmdbGetAllLabels(struct rpmdb * rpmdb) {
    datum rec;
    struct rpmdbLabel * head = NULL;
    struct rpmdbLabel * tail = NULL;
    struct rpmdbLabel * label;

    rpmdb->rpmdbError = RPMDB_NONE;

    rec = gdbm_firstkey(rpmdb->packages);
    while (rec.dptr) {
	label = malloc(sizeof(struct rpmdbLabel));
	if (!label) {
	    rpmdbFreeLabelList(head);
	    rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	    return NULL;
	}
	if (rpmdbLabelstrToLabel(rec.dptr, rec.dsize, label)) {
	    free(label);
	    rpmdbFreeLabelList(head);
	    rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	    return NULL;
	}

	if (!head) {
	    head = label;
	    tail = label;
	} else {
	    tail->next = label;
	    tail = tail->next;
	}

	rec = gdbm_nextkey(rpmdb->packages, rec);
    }

    return head;
}

struct rpmdbLabel * rpmdbFindPackagesByFile(struct rpmdb * rpmdb, char * path) {
    datum rec;
    datum key;
    struct rpmdbLabel * list;

    rpmdb->rpmdbError = RPMDB_NONE;

    key.dptr = path;
    key.dsize = strlen(path);
    rec = gdbm_fetch(rpmdb->pathIndex, key);
    
    if (!rec.dptr) 
	return NULL;
    if (labelstrlistToLabelList(rec.dptr, rec.dsize, &list)) {
	free(rec.dptr);
	rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	return NULL;
    }
    free(rec.dptr);

    return list;
}

struct rpmdbLabel * rpmdbFindPackagesByLabel(struct rpmdb * rpmdb, 
					     struct rpmdbLabel label)

/* the Name has to be here. The version/release fields optionally
   restrict the search. Either will do. */

{
    datum rec;
    datum key;
    struct rpmdbLabel * list;
    struct rpmdbLabel * prospect;
    struct rpmdbLabel * parent;
    int bad;

    rpmdb->rpmdbError = RPMDB_NONE;

    key.dptr = label.name;
    key.dsize = strlen(label.name);
    rec = gdbm_fetch(rpmdb->nameIndex, key);
    
    if (!rec.dptr) 
	return NULL;
    if (labelstrlistToLabelList(rec.dptr, rec.dsize, &list)) {
	free(rec.dptr);
	rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	return NULL;
    }
    free(rec.dptr);

    prospect = list;
    parent = NULL;
    while (prospect) {
	bad = 0;
	if (label.version && strcmp(label.version, prospect->version))
	    bad = 1;
	else if (label.release && strcmp(label.release, prospect->release))
	    bad = 1;

	if (bad) {
	    rpmdbFreeLabel(*prospect);
	    if (!parent) {
		list = prospect->next;
		free(prospect);
		prospect = list;
	    } else {
		parent->next = prospect->next;
		free(prospect);
		prospect = parent->next;
	    }
	} else {
	    prospect = prospect->next;
	}
    }

    return list;
}

struct rpmdbLabel rpmdbMakeLabel(char * name, char * version, char * release,
				 enum rpmdbFreeType freeType) {
    struct rpmdbLabel label;

    label.next = NULL;
    label.freeType = freeType;
    label.name = name;
    label.version = version;
    label.release = release;

    return label;
}

void rpmdbFreeLabelList(struct rpmdbLabel * list) {
    struct rpmdbLabel * saved;

    while (list) {
	rpmdbFreeLabel(*list);
	saved = list->next;
	free(list);
	list = saved;
    }
}

void rpmdbFreeLabel(struct rpmdbLabel label) {
    if (label.freeType == RPMDB_NOFREE) return;

    free(label.name);
    if (label.freeType == RPMDB_FREEALL) {
	free(label.version);
	free(label.release);
    }
}

int rpmdbGetPackageInfo(struct rpmdb * rpmdb, struct rpmdbLabel label,
			struct rpmdbPackageInfo * pinfo) {
    char * labelstr;
    char ** list, ** prelist;
    char ** strptr;
    datum key, rec;
    char * preamble;
    int i, j;

    labelstr = formLabel(label);
    if (!labelstr) {
	rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	return 1;
    }

    key.dptr = labelstr;
    key.dsize = strlen(labelstr);
    
    rec = gdbm_fetch(rpmdb->packages, key);
    if (!rec.dptr) {
	fprintf(stderr, "error: package %s not found in database "
		"(which is probably corrupt)\n", labelstr);
	exit(1);
    }

    list = splitString(rec.dptr, rec.dsize, '\1');
    if (!list) {
	free(rec.dptr);
	rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	return 1;
    }
    free(rec.dptr);

    /* these strdup's should be checked! */

    pinfo->version = strdup(list[1]); 
    pinfo->release = strdup(list[2]); 
    if (strcmp(list[3], "1")) {
	fprintf(stderr, "error: extremely old databases not supported by C rpm\n");
	exit(1);
    }
    pinfo->name = malloc(strlen(list[0]) + strlen(list[4]) + 2);
    strcpy(pinfo->name, list[0]);
    if (strlen(list[4])) {
	strcat(pinfo->name, "-");
	strcat(pinfo->name, list[4]);
    }
    pinfo->labelstr = malloc(strlen(pinfo->name) + strlen(pinfo->version) +
			     strlen(pinfo->release) + 3);
    strcpy(pinfo->labelstr, pinfo->name);
    strcat(pinfo->labelstr, ":");
    strcat(pinfo->labelstr, pinfo->version);
    strcat(pinfo->labelstr, ":");
    strcat(pinfo->labelstr, pinfo->release);

    preamble = list[5];
    pinfo->installTime = atoi(list[6]);
    pinfo->fileCount = atoi(list[7]);
    
    prelist = splitString(preamble, strlen(preamble), '\n');
    if (!prelist) {
	freeSplitString(list);
	rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	return 1;
    }

    /* these are optional */
    pinfo->distribution = NULL;
    pinfo->vendor = NULL;
    pinfo->group = NULL;
    pinfo->description = NULL;

    for (strptr = prelist; *strptr; strptr++) {
	if (!strncmp("Description: ", *strptr, 13))
	    pinfo->description = strdup((*strptr) + 13);
	else if (!strncmp("Distribution: ", *strptr, 14))
	    pinfo->distribution = strdup((*strptr) + 14);
	else if (!strncmp("Vendor: ", *strptr, 8))
	    pinfo->vendor = strdup((*strptr) + 8);
	else if (!strncmp("size: ", *strptr, 6))
	    pinfo->size = atoi((*strptr) + 6);
	else if (!strncmp("Group: ", *strptr, 7))
	    pinfo->group = strdup((*strptr) + 7);
	else if (!strncmp("BuildHost: ", *strptr, 11))
	    pinfo->buildHost = strdup((*strptr) + 11);
    }
    freeSplitString(prelist);

    if (!pinfo->vendor) pinfo->vendor = strdup("");
    if (!pinfo->description) pinfo->description = strdup("");
    if (!pinfo->distribution) pinfo->distribution = strdup("");
    if (!pinfo->group) pinfo->group = strdup("");

    pinfo->files = malloc(sizeof(struct rpmdbFileInfo) * pinfo->fileCount);
    if (!pinfo->files) {
	freeSplitString(list);
	rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	return 1;
    }

    j = 8;
    for (i = 0; i < pinfo->fileCount; i++) {
	pinfo->files[i].path = strdup(list[j++]);
	pinfo->files[i].state = strdup(list[j++]);
	pinfo->files[i].info = strdup(list[j++]);
    }

    freeSplitString(list);
			
    return 0;
}

void rpmdbFreePackageInfo(struct rpmdbPackageInfo package) {
    int i;

    free(package.version);
    free(package.release);
    free(package.name);
    free(package.labelstr);
    free(package.buildHost);
    free(package.vendor);
    free(package.description);
    free(package.distribution);
    free(package.group);

    for (i = 0; i < package.fileCount; i++) {
	free(package.files[i].path);
	free(package.files[i].state);
	free(package.files[i].info);
    }

    free(package.files);
}

const char * rpmdbStrerror(struct rpmdb * rpmdb) {
    switch (rpmdb->rpmdbError) {
      case RPMDB_NONE:
	return "none";
      case RPMDB_GDBM_ERROR:
	return gdbm_strerror(rpmdb->gdbmError);
      case RPMDB_NO_MEMORY:
	return "out of memory";
    }

    return "unknown error";
}

int rpmdbWasError(struct rpmdb * rpmdb) {
    return (rpmdb->rpmdbError != RPMDB_NONE);
}
