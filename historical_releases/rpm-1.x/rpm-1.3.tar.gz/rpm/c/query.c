#include <stdio.h>

#include "header.h"
#include "query.h"
#include "rpmdb.h"
#include "rpmfile.h"

static void doPackageQuery(int queryFlags, char * arg);


void doQuery(enum querysources source, int queryFlags, char * arg) {
    struct rpmdb rpmdb;
    struct rpmdbLabel * list;
    struct rpmdbLabel * label;
    struct rpmdbPackageInfo package;
    int i;
    char * prefix = "";

    if (source == QUERY_SRPM || source == QUERY_RPM) {
	doPackageQuery(queryFlags, arg);
	return;
    }

    if (rpmdbOpen("/var/lib/rpm", RPMDB_READER, &rpmdb)) {
	fprintf(stderr, "rpmdbOpen: %s\n", rpmdbStrerror(&rpmdb));
	exit(1);
    }

    switch (source) {
      case QUERY_SRPM:
      case QUERY_RPM:
	return;

      case QUERY_ALL:
	list = rpmdbGetAllLabels(&rpmdb);
	if (rpmdbWasError(&rpmdb)) {
	    fprintf(stderr, "rpmdbGetAllLabels: %s\n", rpmdbStrerror(&rpmdb));
	    exit(1);
	}
	break;

      case QUERY_SPATH:
      case QUERY_PATH:
	list = rpmdbFindPackagesByFile(&rpmdb, arg);
	if (rpmdbWasError(&rpmdb)) {
	    fprintf(stderr, "rpmdbFindPackagesByFile: %s\n", 
			rpmdbStrerror(&rpmdb));
	    exit(1);
	}
	break;

      case QUERY_SPACKAGE:
      case QUERY_PACKAGE:
	list = rpmdbFindPackagesByLabel(&rpmdb, 
		    rpmdbMakeLabel(arg, NULL, NULL, RPMDB_NOFREE));
	if (rpmdbWasError(&rpmdb)) {
	    fprintf(stderr, "rpmdbFindPackagesByLabel: %s\n", 
			rpmdbStrerror(&rpmdb));
	    exit(1);
	}
	break;
    }

    if (!list) {
	printf("warning: no matches\n");
    } else if (!queryFlags) {
	for (label = list; label; label = label->next) {
	    printf("%s-%s-%s\n", label->name, label->version,
		    label->release);
	}
	rpmdbFreeLabelList(list);
    } else {
	for (label = list; label; label = label->next) {
	    if (rpmdbGetPackageInfo(&rpmdb, *label, &package)) {
		fprintf(stderr, "rpmdbFindPackagesByFile: %s\n", 
			    rpmdbStrerror(&rpmdb));
		exit(1);
	    }
	    if (queryFlags & QUERY_FOR_INFO) {
		printf("Name        : %-27s Distribution: %s\n", 
			package.name, package.distribution);
		printf("Version     : %-27s       Vendor: %s\n", 
			package.version, package.vendor);
		printf("Release     : %-27s   Build Date: %s\n", 
			package.release, "");
		printf("Install date: %-27s   Build Host: %s\n", 
			"", package.buildHost);
		printf("Group       : %s\n", package.group);
		printf("Size        : %d\n", package.size);
		printf("Description : %s\n", package.description);
		prefix = "    ";
	    }
	    if (queryFlags & QUERY_FOR_LIST) {
		for (i = 0; i < package.fileCount; i++) {
		    if (queryFlags & QUERY_FOR_STATE) 
			printf("%s%-9s%s\n", prefix, package.files[i].state,
				package.files[i].path);
		    else
			printf("%s%s\n", prefix, package.files[i].path);
		}
	    }
	    rpmdbFreePackageInfo(package);
	}
	rpmdbFreeLabelList(list);
    }

    rpmdbClose(&rpmdb);
}

static void doPackageQuery(int queryFlags, char * arg) {
    struct rpmHeader header;
    struct rpmHeaderSpec spec;
    char * rc;
    int i;
    char * prefix = "";
        
    rc = hdrReadFromFile(arg, &header);
    if (rc) {
	fprintf(stderr, "hdrReadFromFile: %s\n", rc);
	exit(1);
    }

    if (!queryFlags) {
	printf("%s-%s-%s\n", header.name, header.version, header.release);
    } else {
	if ((rc = hdrParseSpec(&header, &spec))) {
	    fprintf(stderr, "hdrParseSpec: %s\n", rc);
	    exit(1);
	}
	
	if (queryFlags & QUERY_FOR_INFO) {
	    printf("Name        : %-27s Distribution: %s\n", 
		    header.name, spec.distribution);
	    printf("Version     : %-27s       Vendor: %s\n", 
		    header.version, spec.vendor);
	    printf("Release     : %-27s   Build Date: %s\n", 
		    header.release, "");
	    printf("Install date: %-27s   Build Host: %s\n", 
		    "<package file queried>", spec.buildHost);
	    printf("Group       : %s\n", header.group);
	    printf("Size        : %d\n", header.size);
	    printf("Description : %s\n", spec.description);
	    prefix = "    ";
	}

	if (queryFlags & QUERY_FOR_LIST) {
	    for (i = 0; i < spec.fileCount; i++) {
		if (queryFlags & QUERY_FOR_STATE) 
		    switch (spec.files[i].state) {
		      case RPMFILE_STATE_NORMAL:
			printf("%s%-9s%s\n", prefix, "normal", 
				spec.files[i].path);
			break;
		      case RPMFILE_STATE_REPLACED:
			printf("%s%-9s%s\n", prefix, "replaced", 
				spec.files[i].path);
			break;
		}
		else
		    printf("%s%s\n", prefix, spec.files[i].path);
	    }
	}

	hdrSpecFree(&spec);
    }

    hdrFree(&header);
}

