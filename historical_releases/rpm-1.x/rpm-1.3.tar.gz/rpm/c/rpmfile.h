#ifndef H_RPMFILE
#define H_RPMFILE

#define RPMFILE_STATE_NORMAL 0
#define RPMFILE_STATE_REPLACED 1

struct rpmFileInfo {
    char * path;
    int state;
    unsigned short mode;
    unsigned short uid;
    unsigned short gid;
    unsigned short rdev;
    unsigned long size;
    unsigned long mtime;
    char md5[32];
    char * linkto;
    int isconf;
    int isdoc;
} ;

int rpmfileFromSpecLine(char * str, struct rpmFileInfo * fi);
void rpmfileFree(struct rpmFileInfo * fi);

#endif
