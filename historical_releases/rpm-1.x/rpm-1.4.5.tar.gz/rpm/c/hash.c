/* (C) 1995 Erik Troan
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <assert.h>
#include <stdlib.h>

#include "hash.h"

/* This needs the ability to grow */

struct Bucket
{
    char * Key;
    void * Data;
    struct Bucket * Next, * NextSeq, * PrevSeq;
};

struct HashTableStruct
{
    int DataSize;
    int NumBuckets;
    Boolean CacheKeys;
    Boolean CacheData;
    struct Bucket ** Buckets;
    struct Bucket * FirstBucket;
    struct Bucket * LastBucket;
    struct Bucket * CurrBucket;
#ifdef DEBUG
    int Serial;
    int MarkSerial;
#endif
};

unsigned int HashFunction(char * key, int TableSize);

HashTable CreateHashTable(int NumBuckets, int DataSize, Boolean CacheKeys, 
                          Boolean CacheData)
{
    HashTable Tbl;
    
    assert(NumBuckets > 0);
    assert(DataSize > 0);
    assert(CacheKeys == TRUE || CacheKeys == FALSE);
    assert(CacheData == TRUE || CacheData == FALSE);
    
    Tbl = malloc(sizeof(*Tbl));
    
    Tbl->Buckets = calloc(NumBuckets, sizeof(struct Bucket));
    
    Tbl->NumBuckets = NumBuckets;
    Tbl->CacheKeys = CacheKeys;
    Tbl->CacheData = CacheData;
    Tbl->DataSize = DataSize;
    Tbl->LastBucket = Tbl->FirstBucket = NULL;

#ifdef DEBUG
    Tbl->Serial = 1;
#endif    

    return Tbl;
}
    
void FreeHashTable(HashTable Tbl)
{
    struct Bucket * Bucket, * FreeBucket;
    
    assert(Tbl != NULL);

    Bucket = Tbl->FirstBucket;
    while (Bucket)
    {
	if (Tbl->CacheKeys)
	{
	    free(Bucket->Key);
	}
	if (Tbl->CacheData)
	{
	    free(Bucket->Data);
	}
	FreeBucket = Bucket;
	Bucket = Bucket->NextSeq;
	free(FreeBucket);
    }

    free(Tbl->Buckets);
    free(Tbl);
}
    
unsigned int HashFunction(char * s, int TableSize)
{
    unsigned int HashValue;
    
    for (HashValue = 0; *s; s++) HashValue = *s + 31 * HashValue;
    
    return HashValue % TableSize;
}

void * AddToHashTable(HashTable Tbl, char * Key, void * Data)
/* What does a FALSE return mean?? Out of memory or duplicate entry? */
{
    struct Bucket * Bucket;
    unsigned int HashValue;
    
    assert(Tbl != NULL);
    assert(Key != NULL);
    assert(Data != NULL);

#ifdef DEBUG
    Tbl->Serial++;
#endif

    HashValue = HashFunction(Key, Tbl->NumBuckets);
    
    if (SearchHashTable(Tbl, Key))
    {
	return NULL;
    }

    Bucket = malloc(sizeof(*Bucket));
    if (!Bucket) return NULL;
    
    if (Tbl->CacheKeys)
    {
	Bucket->Key = malloc(strlen(Key) + 1);
	if (!Bucket->Key) return NULL;
	strcpy(Bucket->Key, Key);
    }
    else
    {
	Bucket->Key = Key;
    }
    
    if (Tbl->CacheData)
    {
	Bucket->Data = malloc(Tbl->DataSize);
	if (!Bucket->Data)
	{
	    if (Tbl->CacheKeys) free(Bucket->Key);
	    return FALSE;
	}
	
	memcpy(Bucket->Data, Data, Tbl->DataSize);
    }
    else
    {
	Bucket->Data = Data;
    }

    Bucket->NextSeq = NULL;
    if (!Tbl->FirstBucket) 
    {
	Bucket->PrevSeq = NULL;
	Tbl->FirstBucket = Bucket;
	Tbl->LastBucket = Bucket;
    }
    else
    {
	Tbl->LastBucket->NextSeq = Bucket;
	Bucket->PrevSeq = Tbl->LastBucket;
	Tbl->LastBucket = Bucket;
    }
    
    if (Tbl->Buckets[HashValue])
    {
	Bucket->Next = Tbl->Buckets[HashValue];
    }
    else
    {
	Bucket->Next = NULL;
    }	
    Tbl->Buckets[HashValue] = Bucket;

    return Bucket->Data;
}

void RemoveFromHashTable(HashTable Tbl, char * Key)
{

    assert(0); /* This doesn't work! **** */

    assert(Tbl);
    assert(Key);

#ifdef DEBUG
    Tbl->Serial++;
#endif

}

void * SearchHashTable(HashTable Tbl, char * Key)
{
    struct Bucket * Bucket;
    unsigned int HashValue;

    assert(Tbl);
    assert(Key);

    HashValue = HashFunction(Key, Tbl->NumBuckets);
    
    Bucket = Tbl->Buckets[HashValue];

    while (Bucket)
    {
	if (!strcmp(Bucket->Key, Key)) break;
	Bucket = Bucket->Next;
    }

    return (Bucket ? Bucket->Data : NULL);
}

void BeginStepHashTable(HashTable Tbl)
{
    assert(Tbl);

#ifdef DEBUG
    Tbl->MarkSerial = Tbl->Serial;
#endif

    Tbl->CurrBucket = Tbl->FirstBucket;
}

Boolean IterStepHashTable(HashTable Tbl, char ** KeyPtr, void ** DataPtr)
{
    assert(Tbl);
    assert(KeyPtr || DataPtr);
    assert(Tbl->MarkSerial = Tbl->Serial);
    
    if (!Tbl->CurrBucket) return FALSE;

    if (KeyPtr) *KeyPtr = Tbl->CurrBucket->Key;
    if (DataPtr) *DataPtr = Tbl->CurrBucket->Data;

    Tbl->CurrBucket = Tbl->CurrBucket->NextSeq;
    
    return TRUE;
}

Boolean EmptyHashTable(HashTable Table)
{
    assert(Table);
    
    return (Table->FirstBucket == NULL);
}

#ifdef HAS_MAIN

void halt(void)
{
    printf("failed\n");
    exit(1);
}

int main (void)
{
    HashTable T;
    char * s, * key;
    char * tests[][2] = { { "first", "the first item" } ,
    			  { "second", "the second item" },
    			  { "third", "the third item" },
    			  { "fourth", "the fourth item" },
    			  { "fifth", "the fifth item" },
    			  { "sixth", "the sixth item" },
			  { NULL, NULL },
		        } ;
    int i;
    
    T = CreateHashTable(10, 20, FALSE, FALSE);

    if (!EmptyHashTable(T))
    {
	printf("The hash table is really empty\n");
	exit(1);
    }

    for (i = 0; tests[i][0]; i++)
	AddToHashTable(T, tests[i][0], tests[i][1]);  
    
    for (i = 0; tests[i][0]; i++)
    {
        if (!(s = SearchHashTable(T, tests[i][0]))) 
	{
	    printf("error finding %s\n", tests[i][0]);
	    exit(1);
	}
	if (strcmp(s, tests[i][1]))
	{
	    printf("got wrong return (%s) for %s\b", tests[i][1], tests[i][0]);
	    exit(1);
	}
    }

    if (!EmptyHashTable(T))
    {
	printf("The hash table is not empty\n");
	exit(1);
    }

    BeginStepHashTable(T);
    for (i = 0; tests[i][0]; i++)
    {
	if (!IterStepHashTable(T, &key, (void **) &s))
	{
	    printf("Ran out of items after %d steps\n", i);
	    exit(1);
	}
    
	if (strcmp(key, tests[i][0]) || strcmp(s, tests[i][1]))
	{
	    printf("Item out of sequence after %d steps\n", i);
	    exit(1);
	}
    }

    if (IterStepHashTable(T, &key, NULL))
    {
	printf("Extra items left in list\n");
	exit(1);
    }

    printf("passed\n");
}
#endif
