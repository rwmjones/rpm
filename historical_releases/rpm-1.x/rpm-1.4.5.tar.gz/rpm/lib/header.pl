# RPM Package Management System
# Copyright (C) 1995 Red Hat, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

sub package_type {
    local ($packagepath) = @_;

    debug("opening $packagepath");

    open(BF, "<$packagepath") || error("Can't open $packagepath");
    sysread(BF, $header, 88);

    $readbytes = 88;

    ($m1, $m2, $m3, $m4, $major, $minor, $type, $cpu, $name, $specoff, 
	$speclen, $archiveoffset) = unpack("CCCC CC n n a66 N N N", $header);

    if (($m1, $m2, $m3, $m4) != (0xed, 0xab, 0xee, 0xdb)) {
	error("Bad magic number for $packagepath");
    }

    if ($type == 0) {
	return "bin";
    } elsif ($type == 1) {
	return "src";
    }
    return 0;
}

sub readheader {
    local ($returnfd, $packagepath, *aheader, *spec, *pspec) = @_;
    local (@array, $header, $magic, $archiveoffset, $line);
    local ($m1, $m2, $m3, $m4, $major, $minor, $type, $cpu, $name, $speclen);
    local ($readbytes, $returnval, $tmp, $rest, $size, $os, $icon_len);
    local ($group_len);

    debug("opening $packagepath");

    open(BF, "<$packagepath") || error("Can't open $packagepath");
    sysread(BF, $header, 88);

    $readbytes = 88;

    ($m1, $m2, $m3, $m4, $major, $minor, $type, $cpu, $name, $specoff, 
	$speclen, $archiveoffset) = unpack("CCCC CC n n a66 N N N", $header);

    if (($m1, $m2, $m3, $m4) != (0xed, 0xab, 0xee, 0xdb)) {
	error("Bad magic number for $packagepath");
    }

    if ($major > 1) {
	error("Package $packagepath is a version $major RPM package. This
version of rpm can only handle version 1 RPM packages. Check
ftp.redhat.com for information on obtaining a newer version
of rpm.");
    }

    if ($minor > 0) {
	# this is version 1.1, which has a group line, and maybe
	# even an icon -- the icon would be a good thing to have

	&debug("reading version 1.1 header and icon");

	sysread(BF, $rest, 16);

	$readbytes += 16;

	($size, $os, $group_len, $icon_len) = unpack("N N N N", $rest);

	if ($icon_len) {
	    sysread(BF, $line, $group_len);
	    sysread(BF, $aheader{icon}, $icon_len);
	    $readbytes += $group_len;
	    $readbytes += $icon_len;
	}
    }

    &debug("reading ($specoff - $readbytes) to get to spec");
    sysread(BF, $line, $specoff - $readbytes);
    $readbytes += $specoff - $readbytes;

    &debug("reading $speclen bytes of spec");
    sysread(BF, $line, $speclen);
    $readbytes += $speclen;
    @array = split("\n", $line);

    if ($type == 0) {
	$aheader{type} = "bin";
    } elsif ($type == 1) {
	$aheader{type} = "src";
    } else {
	error("Package $packagepath is of an unknown type");
    }

    if ($cpu == 1) {
	$aheader{arch} = "i386";
    } elsif ($cpu == 2) {
	$aheader{arch} = "axp";
    } elsif ($cpu && $aheader{type} == "bin") {
	error("Package $packagepath was compiled for an unknown architecture");
    }

    $aheader{archiveoffset} = $archiveoffset;
    $aheader{name} = $name;

    &parse_spec_array(*array, *spec, *pspec, *spec_source, *spec_patch, 0);

    if ($returnfd) {
	&debug("skipping to ", $archiveoffset - $readbytes, " to get to data");
	sysread(BF, $tmp, $archiveoffset - $readbytes);
	$returnval = BF;
    } else {
	close(BF);
	$returnval = "";
    }

    return $returnval;
}

1;
