# RPM Package Management System
# Copyright (C) 1995 Red Hat, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

# note that this handles speci's with multiple subpackages, although those
# are no longer allowed

${SUBPACKAGE} = "subpackage";
@recfields = ("name", "version", "release", "${SUBPACKAGE}C");
${FILES} = "file";
@subpackagefields = ("name", "preamble", "insttime", "${FILES}C");
@filefields = ("path", "state", "info");

sub rectostr {
    local(%rec) = @_;
    local($count, $i, $a, $field, $j, $string);

    $count = 0;
    foreach $field (@recfields) {
	$a[$count++] = $rec{$field};
    }
    for ($i = 0; $i < $rec{"${SUBPACKAGE}C"}; $i++)
    {
	foreach $field (@subpackagefields) {
	    $a[$count++] = $rec{"${SUBPACKAGE}:$i:$field"};
	}
	for ($j = 0; $j < $rec{"${SUBPACKAGE}:$i:${FILES}C"}; $j++) {
	    foreach $field (@filefields) {
		$a[$count++] = $rec{"${SUBPACKAGE}:$i:${FILES}:$j:$field"};
	    }
	}
    }

    $string = join("\1", @a);

    return $string;
}

sub strtorec {
    local($string, $howmuch) = @_;
    local($count, %r, $i, $j, $field, @a);

    @a = split("\1", $string);
    $count = 0;
    foreach $field (@recfields) {
	$r{$field} = $a[$count++];
    }
 
    if ($howmuch eq "header") { return %r }

    for ($i = 0; $i < $r{"${SUBPACKAGE}C"}; $i++)
    {
	foreach $field (@subpackagefields) {
	    $r{"${SUBPACKAGE}:$i:$field"} = $a[$count++];
	}

	if ($howmuch eq "all") {
	    for ($j = 0; $j < $r{"${SUBPACKAGE}:$i:${FILES}C"}; $j++) {
		foreach $field (@filefields) {
		    $r{"${SUBPACKAGE}:$i:${FILES}:$j:$field"} = $a[$count++];
		}
	    }
	}
    }

    return %r;
}

sub erasesubpackage {
    local (*spec, $num) = @_;
    local ($field, $i);

    &debug("erasing subpackage $num from spec");
    foreach $field (@subpackagefields) {
	delete $tospec{"${SUBPACKAGE}:$fromnum:$field"};
    }

    for ($i = 0; $i < $fromspec{"${SUBPACKAGE}:$fromnum:${FILES}C"}; $i++) {
	foreach $field (@filefields) {
	    delete $tospec{"${SUBPACKAGE}:$fromnum:${FILES}:$i:$field"};
	}
    }

    return %spec;
}

sub copysubpackage {
    local (*tospec, $tonum, *fromspec, $fromnum) = @_;
    local ($i, $field);

    &debug("doing copy to $tonum from $fromnum");

    foreach $field (@subpackagefields) {
	$tospec{"${SUBPACKAGE}:$tonum:$field"} = 
		$fromspec{"${SUBPACKAGE}:$fromnum:$field"};
    }

    for ($i = 0; $i < $fromspec{"${SUBPACKAGE}:$fromnum:${FILES}C"}; $i++) {
	foreach $field (@filefields) {
	    $tospec{"${SUBPACKAGE}:$tonum:${FILES}:$i:$field"} = 
		    $fromspec{"${SUBPACKAGE}:$fromnum:${FILES}:$i:$field"};
	}
    }

    return %tospec;
}
