#ifndef H_HEADER
#define H_HEADER

#include <stdio.h>

/* This isn't what a header looks like in the file though, so be careful */

#define RPM_CPU_INTEL 1
#define RPM_CPU_ALPHA 2
#define RPM_CPU_POWERPC 3
#define RPM_CPU_SPARC 4


#define RPM_RPM 0
#define RPM_SRPM 1

struct rpmFileInfo;

struct rpmHeader {
    unsigned short type, cpu;
    unsigned int size;
    unsigned int os;
    unsigned int iconLength;

    char * name, * version, * release, * group;
    char * icon;

    unsigned int specLength;
    char * spec;
} ;

struct rpmHeaderSpec {
    char * description;
    char * vendor;
    char * distribution;
    char * buildHost;

    int buildTime;

    int fileCount;
    struct rpmFileInfo * files;
} ;

char * hdrReadFromStream(int fd, struct rpmHeader * header);
char * hdrReadFromFile(char * filename, struct rpmHeader * header);
char * hdrParseSpec(struct rpmHeader * header, struct rpmHeaderSpec * spec);
void   hdrFree(struct rpmHeader * header);
void   hdrSpecFree(struct rpmHeaderSpec * spec);

#endif
