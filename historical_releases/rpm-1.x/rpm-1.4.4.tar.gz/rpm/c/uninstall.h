#ifndef H_UNINSTALL
#define H_UNINSTALL

void removePackageFromDB(struct rpmdb * db, struct rpmdbLabel label);

#endif
