/* (C) 1995 Erik Troan
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <assert.h>
#include <stdlib.h>

#include "llist.h"

Boolean EmptyLL(LList * List)

{
    assert(List != NULL);
    
    return (List->Top == NULL && List->Bottom == NULL);
}

Boolean AtTopLL(LList * List)

{
    assert(List != NULL);
    
    return (List->Curr == List->Top);
}

Boolean AtEndLL(LList * List)

{
    assert(List != NULL);
    
    return (List->Curr == List->Bottom);
}

void InitLL(LList * List, unsigned int Size)

{
    assert(List != NULL && Size > 0);
    
    List->Top = NULL;
    List->Bottom = NULL;
    List->Curr = NULL;
    List->Size = Size;
    List->NumItems = 0;
}

void ClearLL(LList * List)

{
    TopLL(List);
    while (DeleteLL(List));
}

Boolean DeleteLL(LList * List)

{
    struct Node * P;

    if (EmptyLL(List)) return FALSE;
    if ((List->Top == List->Curr) && (List->Bottom == List->Curr))
    {
	free(List->Curr);
	List->Curr = NULL;
	List->Top = NULL;
	List->Bottom = NULL;
    }
    else if (List->Top == List->Curr)
    {
	List->Top = List->Curr->Next;
	List->Top->Prev = NULL;
	free(List->Curr);
	List->Curr = List->Top;
    }
    else if (List->Bottom == List->Curr)
    {
	List->Bottom = List->Curr->Prev;
	List->Bottom->Next = NULL;
	free(List->Curr);
	List->Curr = List->Bottom;
    }
    else
    {
	List->Curr->Next->Prev = List->Curr->Prev;
	List->Curr->Prev->Next = List->Curr->Next;
	P = List->Curr->Next;
	free(List->Curr);
	List->Curr = P;
    }

    List->NumItems--;
    
    return TRUE;
}

Boolean AddLL(LList * List, const void * Item)

{
    assert(List != NULL && Item != NULL);
    
    if (!List->Top)
    {
	List->Top = malloc(List->Size+8);
	List->Bottom = List->Top;
	List->Curr = List->Top;
	List->Curr->Next = NULL;
	List->Curr->Prev = NULL;
	memcpy(List->Curr->Data, Item, List->Size);
    }
    else
    {
	List->Bottom->Next = malloc(List->Size+8);
	List->Bottom->Next->Prev = List->Bottom;
	List->Bottom = List->Bottom->Next;
	List->Bottom->Next = NULL;
            memcpy(List->Bottom->Data, Item, List->Size);
    }

    List->NumItems++;
    
    return TRUE;
}

Boolean AddTopLL(LList * List, const void * Item)
{
    assert(List != NULL && Item != NULL);

    if (!List->Top)
    {
	return AddLL(List, Item);
    }
    
    List->Top->Prev = malloc(List->Size+8);
    List->Top->Prev->Next = List->Top;
    List->Top = List->Top->Prev;
    List->Top->Prev = NULL;
    memcpy(List->Top->Data, Item, List->Size);

    List->NumItems++;
    
    return TRUE;
}

Boolean UpdateLL(LList * List, const void * Item)

{
    assert(List != NULL && Item != NULL);
    
    if (!List->Curr) return FALSE;
    
    memcpy(List->Curr->Data, Item, List->Size);
    return TRUE;
}

void TopLL(LList * List)

{
    assert(List != NULL);
    
    List->Curr = List->Top;
}

void EndLL(LList * List)

{
    assert(List != NULL);
    
    List->Curr = List->Bottom;
}

Boolean NextLL(LList * List)

{
    assert(List != NULL);
    
    List->Curr = List->Curr->Next;
    if (List->Curr) return TRUE; else return FALSE;
}

Boolean PrevLL(LList * List)

{
    assert(List != NULL);
    
    List->Curr = List->Curr->Prev;
    if (List->Curr) return TRUE; else return FALSE;
}

LLMarker SavePosLL(LList * List)

{
    assert(List != NULL);
    
    return List->Curr;
}

void RestorePosLL(LList * List, LLMarker Save)

{
    assert(List != NULL && Save != NULL);
    
    List->Curr = Save;
}

Boolean GetLL(LList * List, void * Item)

{
    assert(List != NULL && Item != NULL);
    
    if (!List->Curr) return FALSE;
    
    memcpy(Item, List->Curr->Data, List->Size);
    return TRUE;
}

Boolean IterGetLL(LList * List, void * Item)

{
    assert(List != NULL && Item != NULL);
    
    if (!List->Curr) return FALSE;

    memcpy(Item, List->Curr->Data, List->Size);

    List->Curr = List->Curr->Next;

    return TRUE;
}

Boolean PastEndLL(LList * List)

{
    assert(List != NULL);
    
    return (List->Curr == NULL);
}

Boolean PastTopLL(LList * List)

{
    assert(List != NULL);
    
    return (List->Curr == NULL);
}

void ConcatLL(LList * Left, LList * Right)
{
    assert(Left != NULL);
    assert(Right != NULL);
    assert(Left->Size == Right->Size);

    Left->Bottom->Next = Right->Top;
    Right->Bottom->Prev = Right->Bottom;
    Left->Bottom = Right->Bottom;
    Left->NumItems += Right->NumItems;
    
#ifdef DEBUG
    Right->Top = NULL;
    Right->Size = 0;
    Right->Bottom = NULL;
#endif
}

unsigned int NumItemsLL(LList * List)
{
    assert(List != NULL);
    
    return (List->NumItems);
}    

/*
void main ()

{
    int i;
    char s[100];
    LList L;
    
    printf("mem %u\n",coreleft());
    
    InitLL(&L, 100);
    
    for (i=0;i<5;i++)
    {
	gets(s);
	AddLL(&L, s);
    }
    printf("mem %u\n",coreleft());
    
    TopLL(&L);
    puts(" ");
    while (GetLL(&L, s))
    {
	puts(s);
	NextLL(&L);
    }
    
    ClearLL(&L);
    printf("mem %u\n",coreleft());
    
}              */
