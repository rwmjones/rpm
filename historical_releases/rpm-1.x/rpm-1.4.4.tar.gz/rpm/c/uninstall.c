#include <stdlib.h>

#include "messages.h"
#include "rpmdb.h"
#include "rpmfile.h"
#include "uninstall.h"

static struct rpmdbLabel * removeLabelFromLabelList(struct rpmdbLabel * list, 
					          struct rpmdbLabel label);

void removePackageFromDB(struct rpmdb * db, struct rpmdbLabel label) {
    struct rpmdbPackageInfo package;
    struct rpmdbLabel * list;
    int i;
    char * labelstr;

    labelstr = rpmdbLabelToLabelstr(label, 0);

    rpmdbGetPackageInfo(db, label, &package);

    for (i = 0; i < package.fileCount; i++) {
	list = rpmdbFindPackagesByFile(db, package.files[i].path);
	list = removeLabelFromLabelList(list, label);
	rpmdbUpdateFilelist(db, package.files[i].path, list);
	rpmdbFreeLabelList(list);
    }
    rpmdbFreePackageInfo(package);
    
    list = rpmdbFindPackagesByLabel(db,
		rpmdbMakeLabel(label.name, NULL, NULL, -1, RPMDB_NOFREE));
    list = removeLabelFromLabelList(list, label);

    rpmdbUpdateNamelist(db, package.name, list);
    rpmdbFreeLabelList(list);

    rpmdbRemoveIcon(db, labelstr); 
    rpmdbRemoveGroup(db, labelstr);
    rpmdbRemoveScripts(db, labelstr);
    rpmdbRemovePackageEntry(db, labelstr);

    free(labelstr);
}

static struct rpmdbLabel * removeLabelFromLabelList(struct rpmdbLabel * list, 
					          struct rpmdbLabel label) {
    struct rpmdbLabel * tmp, * tmp2;
    int found;

    if (!rpmdbLabelCmp(list, &label)) {
	tmp = list;
	list = list->next;
	rpmdbFreeLabel(*tmp);
	free(tmp);
    } else {
	found = 0;
	tmp = list;
	while (tmp->next) {
	    if (!rpmdbLabelCmp(tmp->next, &label)) {
		found = 1;
		tmp2 = tmp->next;
		tmp->next = tmp2->next;
		rpmdbFreeLabel(*tmp2);
		free(tmp2);
		/* could break, but not doing so cleans up anything
		   extra that might be in the file list */
	    } else {
		tmp = tmp->next;
	    }
	}
	    
	if (!found) {
	    message(MESS_ERROR, "package %s not found in list"
		    " -- database corrupt", 
		    rpmdbLabelToLabelstr(label, 1));
	}
    }

    return list;
}
