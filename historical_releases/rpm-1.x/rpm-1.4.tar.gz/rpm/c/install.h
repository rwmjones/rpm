#ifndef H_INSTALL
#define H_INSTALL

void doInstall(char * arg, int force, int test);

#endif
