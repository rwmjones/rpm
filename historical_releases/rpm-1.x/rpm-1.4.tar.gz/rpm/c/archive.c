#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "archive.h"
#include "messages.h"

int undoArchive(int s, char * path) {
    pid_t gzipPID;
    pid_t cpioPID;
    int status;
    int fd[2];
    int out_fd[2];
    char buf[300];
    int i;
    void * oldhandler;

    if (access("/bin/cpio",  X_OK)) 
	message(MESS_FATALERROR, "cannot exec /bin/cpio: %s\n", 
		strerror(errno));
    if (access("/bin/gzip",  X_OK)) 
	message(MESS_FATALERROR, "cannot exec /bin/gzip: %s\n", 
		strerror(errno));

    oldhandler = signal(SIGPIPE, SIG_IGN);

    if (pipe(fd))
	message(MESS_FATALERROR, "cannot create pipe: %s\n", strerror(errno));

    if (!(gzipPID = fork())) {
	close(0);
	close(1);
	close(fd[0]);
	dup2(s, 0);
	dup2(fd[1], 1);
	close(fd[2]);
	close(s);
	execl("/bin/gzip", "/bin/gzip", "-d", NULL);
	message(MESS_FATALERROR, "execl() of /bin/gzip failed: %s\n",
		strerror(errno));
	exit(-1);
    }
    close(s);

    if (pipe(out_fd))
	message(MESS_FATALERROR, "cannot create pipe: %s\n", strerror(errno));

    if (!(cpioPID = fork())) {
	close(0);

	close(fd[1]);
	close(out_fd[0]);
	close(1);
	close(2);
	dup2(fd[0], 0);
	dup2(out_fd[1], 1);
	dup2(out_fd[1], 2);
	close(out_fd[1]);
	close(fd[0]);
	chdir(path);
	execl("/bin/cpio", "/bin/cpio", "-ivumd", NULL);
	message(MESS_FATALERROR, "execl() of /bin/cpio failed: %s\n",
		strerror(errno));
	exit(-1);
    }

    close(fd[0]);
    close(fd[1]);
    close(out_fd[1]);

    while ((i = read(out_fd[0], buf, sizeof(buf) - 1))) {
	buf[i] = '\0';
	/*printf("e: %s", buf);*/
    }

    close(out_fd[0]);

    signal(SIGPIPE, oldhandler);

    if (waitpid(gzipPID, &status, 0) == -1) 
	perror("waitpid");

    if (!WIFEXITED(status) || WEXITSTATUS(status)) {
	message(MESS_ERROR, "unpack of gzip portion of package failed\n");
	return 1;
    }
    waitpid(cpioPID, &status, 0);
    if (!WIFEXITED(status) || WEXITSTATUS(status)) {
	message(MESS_ERROR, "unpack of cpio portion of package failed\n");
	return 1;
    }

    return 0;
}
