# RPM Package Management System
# Copyright (C) 1995 Red Hat, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

# -*-perl-*-

sub usage {
    print "rpm version $rpm{'version'}
$rpm{copyright}

usage: rpm {--help}
       rpm {--version}
       rpm {--install -i} [-v] [--hash -h] [--percent] [--force] [--test]
                          [--search] file1.rpm file2.rpm ... filen.rpm
       rpm {--upgrage -U} [-v] [--hash -h] [--percent] [--force] [--test]
                          [--search] file1.rpm file2.rpm ... fileN.rpm
       rpm {--query -q} [-afFpP] [-i] [-l] [-s] [-d] [-c] [-v] [targets]
       rpm {--verify -V -y] [-afFpP] [targets]
       rpm {--uninstall -u] package1 package2 ... packageN
       rpm {-b}[plciba] [-v] [--short-circuit] [--clean] [--keep-temps]
                        [--test] [--time-check <s>] specfile
       rpm {--rebuild} [-v] source1.rpm source2.rpm ... sourceN.rpm
       rpm {--where} package1 package2 ... packageN
" 
}

sub help {
    print "rpm version $rpm{'version'}
$rpm{copyright}

    Usage:
   --help		- print this message
   --version		- print the version of rpm being used
    -q                  - query mode
      Package specification options:
        -a                - query all packages
        -f <file>+        - query package owning <file>
        -F                - like -f, but read file names from stdin
        -p <packagefile>+ - query (uninstalled) package <packagefile>
        -P                - like -f, but read package names from stdin
      Information selection options:
        -i                - display package information
        -l                - display package file list
        -s                - show file states (implies -l)
        -d                - list only documentation files (implies -l)
        -c                - list only configuration files (implies -l)

    -V
    -y
    --verify            - verify a package installation
			  same package specification options as -q

    --install <packagefile>
    -i <packagefile>	- install package
       -v	        - be a little verbose 
       -h
      --hash            - print hash marks as package installs (good with -v)
      --percent         - print percentages as package installs
      --force           - install despite potential conflicts
      --test            - don't install, but tell if it would work or not
      --search          - search the paths listed in /etc/rpmrc for rpms

    --upgrade <packagefile>
    -U <packagefile>	- upgrade package (same options as --install)

    --uninstall <package>
    -u <package>        - uninstall package

    -b<stage> <spec>    - build package, where <stage> is one of:
			  p - prep (unpack sources and apply patches)
			  l - list check (do some cursory checks on %files)
			  c - compile (prep and compile)
			  i - install (prep, compile, install)
			  b - binary package (prep, compile, install, package)
			  a - bin/src package (prep, compile, install, package)
      --short-circuit   - skip straight to specified stage (only for c,i)
      --clean           - remove build tree when done
      --keep-temps      - do not delete scripts (or any temp files) in /tmp
      --test            - do not execute any stages, implies --keep-temps
			  in /tmp - useful for testing
      --time-check <s>  - set the time check to S seconds (0 disables it)

    --where <pkg>+      - search paths listed in /etc/rpmrc for rpms
                          matching <pkg>

    --rebuild <source_package>
                        - install source package, build binary package,
                          and remove spec file, sources, patches, and icons.\n";
}

1;
