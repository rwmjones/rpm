# RPM Package Management System
# Copyright (C) 1995 Red Hat, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

require "ctime.pl";
require "dbrecord.pl";
require "dbmisc.pl";

sub showpackages {
    local (*querymodes, @packages) = @_;
    local ($package);

    &debug("display packages in list @packages");

    if (!@packages) {
	warning("no matches");
	return 1;
    }

    foreach $package (@packages) {
	if ($package ne "--version--") {
	    showpackage(*querymodes, $package);
	}
    }
}

sub showpackage {
    local (*querymodes, $package) = @_;
    local($psecstr, %spec);

    &debug("info on $package");

    $specstr = $Packages{$package};
    if (!defined $specstr) {
	#&error("Database corrupt. Mail support\@redhat.com (4).");
	&warning("Database corrupt. Mail support\@redhat.com (5).");
	return
    }

    if (!$querymodes{list} && !$querymodes{info}) {
	%spec = &strtorec($specstr, "subs");
    } elsif (!$querymodes{list} && $querymodes{info}) {
	%spec = &strtorec($specstr, "subs");
    } else {
	%spec = &strtorec($specstr, "all");
    }

    showpackagespec(*querymodes, *spec);
}

sub showpackagespec {
    local (*querymodes, *spec) = @_;
    local ($i, $j, $prefix, $state, $label);
    local ($name, $version, $release);

    debug("showing ", " for $spec{name}");

    if (!$querymodes{info} && !$querymodes{list}) {
	$name = $spec{name};         $version = $spec{version};
	$release = $spec{release}; 
	
	if ($spec{"subpackage:0:name"}) {
	    &normal("$name-", $spec{"subpackage:0:name"}, 
		"-$version-$release");
	} else {
	    &normal("$name-$version-$release");
	}
	$prefix = "    ";
	return 0;
    } elsif ($querymodes{info}) {
	debug("printing info");
	&print_preamble("", 0, *spec);
	if (!$querymodes{list}) {
	    return 0;
	}
	$prefix = "    ";
    } else {
	$prefix = "";
    }

    debug("looking at $name $querymodes{list} $querymodes{info}");

    debug("fileC = ", $spec{"subpackage:0:fileC"});
    if ($querymodes{list}) {
	for ($i = 0; $i < $spec{"subpackage:0:fileC"}; $i++) {
	    if (($querymode{doc} &&
		 (&is_realdoc($spec{"subpackage:0:file:$i:info"}))) ||
		($querymode{config} &&
		 (&is_config($spec{"subpackage:0:file:$i:info"}))) ||
		(!$querymode{doc} && !$querymode{config})) {
		
		$state = sprintf("%-9s", 
				$spec{"subpackage:0:file:$i:state"} . " ")
			if $querymodes{state};
		if (&isverbose) {
		    $post = " " . $spec{"subpackage:0:file:$i:info"};
		}
		&normal($prefix, $state, $spec{"subpackage:0:file:$i:path"},
			$post);
	    }
	}
    }
}

sub doquery {
    local($what, *querymode, @args) = @_;

    &opendatabase("ro");

    &debug("Doing $what query of @args");

    $what =~ /^all$/ && &showpackages(*querymode, sort(keys(%Packages)));
    $what =~ /^whence$/ && &showpackages(*querymode, whence(@args));
    $what =~ /^Whence$/ && &showpackages(*querymode, whence(&stdinlist()));
    $what =~ /^package$/ && &showrpmpackages(*querymode, @args);
    $what =~ /^Package$/ && &showrpmpackages(*querymode, &stdinlist());
    $what =~ /^$/ && &showpackages(*querymode, &getmultmatches(@args));

    &closedatabase;
}

sub showrpmpackages {
    local (*querymode, @list) = @_;
    local ($file, %header, %spec, %pspec);

    require "build.pl";
    require "spec.pl";
    require "header.pl";

    foreach $file (@list) {
	&debug("reading spec file from $file");

	&readheader("", $file, *header, *spec, *pspec);

	showpackagespec(*querymode, *spec);
    }
}

sub print_preamble {
    local ( $pre, $x, *spec ) = @_;
    local ( $res, $instdate, $distribution, $vendor, $misc );
    local ( $builddate, $buildhost, $description );
    local ( $i, $foo, $arg, $indesc, $descpre, $line, $subname, $group );

    if (defined $spec{"subpackage:$x:insttime"}) {
	$instdate = &ctime($spec{"subpackage:$x:insttime"});
	chop($instdate);
    } else {
	$instdate = "<not installed>";
    }

    $indesc = 0;
    $descpre = "Description : ";
    $group = "<none>";
    foreach $line (split('\n', $spec{"subpackage:$x:preamble"})) {
 	$_ = $line;
	&debug("preamble -> ", $_);
	($foo, $arg) = split;
	/^source([0-9]*):/i && (next);
	/^patch([0-9]*):/i && (next);
	/^size:/i && ($size = $arg, next);
	/^group:/i && ($group = $arg, next);
	/^buildhost:/i && ($buildhost = $arg, next);
	/^builddate:/i && ($builddate = &ctime($arg), chop($builddate), next);
	$arg = $line;
	$arg =~ s/^\S+\s+//;
	/^distribution:/i && ($distribution = $arg, next);
	/^vendor:/i && ($vendor = $arg, next);
	/^description:/i && do {
	    $line =~ s/^\S+\s+//;
	    $indesc = 1;
	};
	if ($indesc) {
	    if ($line =~ /\\$/) {
		# Not end of description
		$line =~ s/\\$//;
	    } else {
		$indesc = 0;
	    }
	    $description .= $pre . $descpre . $line . "\n";
	    $descpre = "             ";
	    next;
	}
	$misc .= $pre . $line . "\n";
    }

    $name = $spec{"name"};
    if ($spec{"subpackage:$x:name"}) {
        $name .= "-" . $spec{"subpackage:$x:name"};
    }

    printf("%sName        : %-27s Distribution: %s\n", $pre, $name, $distribution);
    printf("%sVersion     : %-27s       Vendor: %s\n", $pre, $spec{"version"}, $vendor);
    printf("%sRelease     : %-27s   Build date: %s\n", $pre, $spec{"release"}, $builddate);
    printf("%sInstall date: %-27s   Build host: %s\n", $pre, $instdate, $buildhost);
    printf("%sGroup       : %s\n", $pre, $group);
    printf("%sSize        : %-27s\n", $pre, $size);

#    print $misc;
    printf("%s", $description);
}

1;
