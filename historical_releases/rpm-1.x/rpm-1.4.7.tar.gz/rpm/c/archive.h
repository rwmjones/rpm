#ifndef H_ARCHIVE

int undoArchive(int s, char * path);

#endif
