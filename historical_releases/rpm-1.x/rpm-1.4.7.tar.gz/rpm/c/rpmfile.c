#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "messages.h"
#include "misc.h"
#include "rpmfile.h"

char * rpmfileStateStrs[] = { "normal", "replaced" };

static void infoFromFields(char ** fields, struct rpmFileInfo * fi);

void rpmfileFromInfoLine(char * path, char * state, char * str, 
			struct rpmFileInfo * fi) {
    char ** fields;

    fields = splitString(str, strlen(str), ' ');

    fi->path = strdup(path);
    if (!strcmp(state, "normal"))
	fi->state = RPMFILE_STATE_NORMAL;
    else if (!strcmp(state, "replaced"))
	fi->state = RPMFILE_STATE_REPLACED;
    else 
	message(MESS_FATALERROR, "unknown file state: %s", state);

    infoFromFields(fields, fi);

    freeSplitString(fields);
}

void rpmfileFromSpecLine(char * str, struct rpmFileInfo * fi) {
    char ** fields;

    fields = splitString(str, strlen(str), ' ');

    fi->path = strdup(fields[0]);
    fi->state = RPMFILE_STATE_NORMAL;

    infoFromFields(fields + 1, fi);

    freeSplitString(fields);
}

void infoFromFields(char ** fields, struct rpmFileInfo * fi) {
    fi->size = strtol(fields[0], NULL, 10);
    fi->mtime = strtol(fields[1], NULL, 10);
    strcpy(fi->md5, fields[2]);
    fi->mode = strtol(fields[3], NULL, 8);
    fi->uid = strtol(fields[4], NULL, 10);
    fi->gid = strtol(fields[5], NULL, 10);
    fi->isconf = fields[6][0] != '0';
    fi->isdoc = fields[7][0] != '0';
    fi->rdev = strtol(fields[8], NULL, 16);
   
    if (S_ISLNK(fi->mode)) {
	fi->linkto = strdup(fields[9]);
	if (!fi->linkto) {
	    free(fi->path);
	    freeSplitString(fields);
	    message(MESS_FATALERROR, "out of memory");
	}
    } else {
	fi->linkto = NULL;
    }
}

void rpmfileFree(struct rpmFileInfo * fi) {
    free(fi->path);
    fi->linkto ? free(fi->linkto) : 0;
}

char * rpmfileToInfoStr(struct rpmFileInfo * fi) {
    char * buf;

    if (fi->linkto) 
	buf = malloc(strlen(fi->linkto) + 100);
    else
	buf = malloc(100);

    sprintf(buf, "%ld %ld %s %o %d %d %s %s %x ", fi->size, fi->mtime,
		fi->md5, fi->mode, fi->uid, fi->gid,
		fi->isconf ? "1" : "0", fi->isdoc ? "1" : "0",
		fi->rdev);
    
    if (fi->linkto) 
	strcat(buf, fi->linkto);
    else
	strcat(buf, "X");
 
    return buf;
}
