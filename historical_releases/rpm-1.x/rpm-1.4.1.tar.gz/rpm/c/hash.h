#ifndef HASH_ALREADY_DEFINED
#define HASH_ALREADY_DEFINED

/* (C) 1995 Erik Troan
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* These hash tables have a couple of crucial features.

   1) They grow. If any bucket location gets too many items in it
      the buckets gets replaced by a nested hash table. [not yet though ***]

   2) You can traverse them linearly. The order of this traversal
      is the same as the order that items were added in
*/

#include "types.h"

typedef struct HashTableStruct * HashTable;
typedef struct HashTableMarker * HashTableMarker;

HashTable CreateHashTable(int Buckets, int DataSize, Boolean CacheKeys,
                          Boolean CacheData);
void FreeHashTable(HashTable Tbl);
void * AddToHashTable(HashTable Tbl, char * Key, void * Data);
   /* Returns pointer to Data, like SearchHashTable() or NULL if error */
void RemoveFromHashTable(HashTable Tbl, char * Key);
void * SearchHashTable(HashTable Tbl, char * Key);

void BeginStepHashTable(HashTable Table);
Boolean IterStepHashTable(HashTable Table, char ** KeyPtr, void ** DataPtr);
Boolean EmptyHashTable(HashTable Table);

#endif
