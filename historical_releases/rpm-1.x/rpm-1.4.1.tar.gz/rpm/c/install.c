#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "archive.h"
#include "hash.h"
#include "header.h"
#include "install.h"
#include "md5.h"
#include "messages.h"
#include "rpmdb.h"
#include "rpmfile.h"
#include "uninstall.h"

static void doStreamInstall(struct rpmdb * db, int stream, char * packageFile,
			    int force, int test);
HashTable findConflictingPackages(struct rpmdb * db, 
				  struct rpmHeaderSpec spec);
static int mymkdir(char * path, int test);
static int myunlink(char * path, int test);
static int myrename(char * path, char * newpath, int test);

void doInstall(char * packageFile, int force, int test) {
    int package;
    struct rpmdb rpmdb;
    
    message(MESS_DEBUG, "installing package: %s\n", packageFile);
        
    package = open(packageFile, O_RDONLY);
    if (package < 0) {
	message(MESS_ERROR, "cannot open %s: %s\n", packageFile, 
			strerror(errno));
	return;
    }

    rpmdbOpen(RPMDB_WRITER, &rpmdb);

    doStreamInstall(&rpmdb, package, packageFile, force, test);

    close(package);
}

static void doStreamInstall(struct rpmdb * db, int stream, char * packageFile,
			    int force, int test) {
    struct rpmHeader header;
    struct rpmHeaderSpec spec;
    struct rpmdbLabel * labelptr, * list;
    struct rpmdbPackageInfo package;
    struct rpmFileInfo * fileinfo;
    char * labelstr;
    char * chptr;
    char * newPackageLabelStr;
    struct rpmdbLabel newPackageLabel;
    char * rc;
    char intrc;
    int i;
    HashTable conflictingPackages;
    HashTable newFiles;
    HashTable subdirs;
    HashTable cfgFileSums;
    HashTable savedFiles;
    int samePackage;
    int alreadyInstalled = 0;
    int error;
    struct stat statinfo;
    char * dbmd5;
    char diskmd5[33];
    char * newname, * oldname;

    rc = hdrReadFromStream(stream, &header);
    if (rc) {
	message(MESS_ERROR, "reading %s: %s\n", packageFile, rc);
	return;
    }

    if ((rc = hdrParseSpec(&header, &spec))) {
	hdrFree(&header);
	message(MESS_ERROR, "reading %s: %s\n", packageFile, rc);
	return;
    }

    newPackageLabel = rpmdbMakeLabel(header.name, header.version, 
				     header.release, -1, RPMDB_NOFREE);
    newPackageLabelStr = rpmdbLabelToLabelstr(newPackageLabel, 0);

    savedFiles = CreateHashTable(spec.fileCount, sizeof(char *),
				  TRUE, FALSE);
    cfgFileSums = CreateHashTable(spec.fileCount, sizeof(char) * 33,
				  TRUE, TRUE);
    subdirs = CreateHashTable(spec.fileCount, sizeof(void *), 
				TRUE, FALSE);
    newFiles = CreateHashTable(spec.fileCount * 3, sizeof(void *), 
				FALSE, FALSE);
    for (i = 0; i < spec.fileCount; i++)
	AddToHashTable(newFiles, spec.files[i].path, &spec.files[i]);

    conflictingPackages = findConflictingPackages(db, spec);

    error = 0;
    BeginStepHashTable(conflictingPackages);
    while (IterStepHashTable(conflictingPackages, &labelstr, 
			     (void **) &labelptr)) {
	message(MESS_DEBUG, "new: %s old: %s\n", newPackageLabelStr, labelstr);
	alreadyInstalled += samePackage = !strcmp(labelstr, newPackageLabelStr);
	
	message(MESS_DEBUG, "%s shares files with %s\n", packageFile, labelstr);

	rpmdbGetPackageInfo(db, *labelptr, &package);

	for (i = 0; i < package.fileCount; i++) {
	    if ((fileinfo = SearchHashTable(newFiles, package.files[i].path))){
		message(MESS_DEBUG, "    %s is in both\n", 
			package.files[i].path); 
		
		if (strcmp(package.files[i].md5, fileinfo->md5)) {
		    if (!samePackage && !force) {
			message(MESS_ERROR, "%s conflicts with file from %s\n",
				package.files[i].path, labelstr);
			error = 1;
		    } else if (!samePackage)
			message(MESS_WARNING, "%s conflicts with file from "
				"%s\n", package.files[i].path, labelstr);
		}

		if (package.files[i].isconf && 
                    package.files[i].state == RPMFILE_STATE_NORMAL) {
			AddToHashTable(cfgFileSums, package.files[i].path, 
					package.files[i].md5);
		}
	    }
	}

	rpmdbFreePackageInfo(package);
    }

    if (error) {
	FreeHashTable(conflictingPackages);
	FreeHashTable(newFiles);
	FreeHashTable(subdirs);
	FreeHashTable(cfgFileSums);
	FreeHashTable(savedFiles);
	free(newPackageLabelStr);
	hdrSpecFree(&spec);
	hdrFree(&header);
	return;
    }

    if (alreadyInstalled) {
	if (!force) {
	    message(MESS_ERROR, "package %s is already installed - use --force to reinstall it\n",
			newPackageLabelStr);
	    FreeHashTable(conflictingPackages);
	    FreeHashTable(newFiles);
	    FreeHashTable(subdirs);
	    FreeHashTable(cfgFileSums);
	    FreeHashTable(savedFiles);
	    free(newPackageLabelStr);
	    hdrSpecFree(&spec);
	    hdrFree(&header);
	    return;
	}
	
	message(MESS_DEBUG, "package %s is already installed - removing it\n",
			newPackageLabelStr);

	/* remove package from the database */
	removePackageFromDB(db, newPackageLabel);
    }

    /* handle config files and missing subdirectories. unfortunately,
       cpio does mkdir() with bad permissions! */
    for (i = 0; i < spec.fileCount; i++) {
	for (chptr = spec.files[i].path + 1; *chptr; chptr++) {
	    if (*chptr == '/') {
		*chptr = '\0';
		if (!SearchHashTable(subdirs, spec.files[i].path)) 
		    AddToHashTable(subdirs, spec.files[i].path, chptr);
		*chptr = '/';
	    }
	}

	if (spec.files[i].isconf) {
	    if (stat(spec.files[i].path, &statinfo)) {
		if (errno != ENOENT) {
		    message(MESS_ERROR, "cannot stat %s: %s\n", chptr, 
			    strerror(errno));
		    error = 1;
		    break;
		} 
		/* otherwise the file isn't on the disk, and we don't
		   have to do anything special for it */
	    } else {
		char * s;

		if (!(dbmd5 = SearchHashTable(cfgFileSums, spec.files[i].path)))
		{
		    if (!(s = malloc(strlen(spec.files[i].path) + 20)))
			message(MESS_FATALERROR, "out of memory");

		    strcpy(s, spec.files[i].path);
		    strcat(s, ".rpmsave");

		    message(MESS_NORMAL, "saving %s as %s\n", 
			    spec.files[i].path, s);

		    if (myrename(spec.files[i].path, s, test)) 
			error = 1;

		    free(s);
		} else if (!strcmp(dbmd5, spec.files[i].md5)) {
		    if (!(s = malloc(strlen(spec.files[i].path) + 20)))
			message(MESS_FATALERROR, "out of memory");

		    strcpy(s, spec.files[i].path);
		    strcat(s, ".rpm-backup");

		    message(MESS_DEBUG, "backing up %s as %s\n", 
			    spec.files[i].path, s);
		    AddToHashTable(savedFiles, spec.files[i].path, s);

		    if (myrename(spec.files[i].path, s, test)) 
			error = 1;

		    /* in case of error, s doesn't get freed! */
		} else if (mdfile(spec.files[i].path, diskmd5)) {
		    message(MESS_WARNING, "cannot compute md5 of %s\n",
			    spec.files[i].path);
		} else if (!strcmp(diskmd5, dbmd5)) {
		    message(MESS_DEBUG, "config file %s has not "
			    "been changed -- overwriting\n",
			     fileinfo->md5);
		} else if (!strcmp(diskmd5, fileinfo->md5)) {
		    message(MESS_DEBUG, "config file has been changed to "
			    "the new version-- overwriting\n",
			     fileinfo->md5);
		} else {
		    if (!(s = malloc(strlen(spec.files[i].path) + 20)))
			message(MESS_FATALERROR, "out of memory");

		    strcpy(s, spec.files[i].path);
		    strcat(s, ".rpmsave");

		    message(MESS_NORMAL, "saving %s as %s\n", 
			    spec.files[i].path, s);

		    if (myrename(spec.files[i].path, s, test)) 
			error = 1;

		    free(s);
		}
	    }
	}
    } 

    FreeHashTable(cfgFileSums);

    BeginStepHashTable(subdirs);
    while (!error && IterStepHashTable(subdirs, &chptr, NULL)) {
	if (stat(chptr, &statinfo)) {
	    if (errno != ENOENT) {
		error = 1;
		message(MESS_ERROR, "cannot stat %s: %s\n", chptr, 
			strerror(errno));
	    }
	    message(MESS_DEBUG, "creating directory %s\n", chptr);
	    mymkdir(chptr, test);
	} else if (!S_ISDIR(statinfo.st_mode)) {
	    myunlink(chptr, test);
	    mymkdir(chptr, test);
	}
    }

    FreeHashTable(subdirs);

    if (test) {
	message(MESS_NORMAL, "installation of %s-%s-%s would succeed\n", 
		header.name, header.version, header.release);
	error = 1;
    }

    if (error) {
	FreeHashTable(conflictingPackages);
	FreeHashTable(newFiles);
	FreeHashTable(savedFiles);
	free(newPackageLabelStr);
	hdrSpecFree(&spec);
	hdrFree(&header);
	return;
    }


    /* chdir() and unpacking goes here */
    intrc = undoArchive(stream, "/");
   
    BeginStepHashTable(savedFiles);
    while (IterStepHashTable(savedFiles, &newname, (void **) &oldname)) {
	myrename(oldname, newname, test);
    }
    FreeHashTable(savedFiles);

    if (intrc) {
	FreeHashTable(conflictingPackages);
	FreeHashTable(newFiles);
	free(newPackageLabelStr);
	hdrSpecFree(&spec);
	hdrFree(&header);
	return;
    }

    /* update the database to reflect this mess */
    for (i = 0; i < spec.fileCount; i++) {
	list = rpmdbFindPackagesByFile(db, spec.files[i].path);
	
	newPackageLabel.next = list;
	newPackageLabel.fileNumber = i;
	
	rpmdbUpdateFilelist(db, spec.files[i].path, &newPackageLabel);

	rpmdbFreeLabelList(list);
    }

    list = rpmdbFindPackagesByLabel(db,
		rpmdbMakeLabel(header.name, NULL, NULL, -1, RPMDB_NOFREE));
    newPackageLabel.next = list;
    newPackageLabel.fileNumber = -1;
    rpmdbUpdateNamelist(db, header.name, &newPackageLabel);
    rpmdbFreeLabelList(list);

    package.name = header.name;
    package.version = header.version;
    package.release = header.release;
    package.labelstr = newPackageLabelStr;
    package.installTime = time(NULL);
    package.buildTime = spec.buildTime;
    package.size = header.size;
    package.description = spec.description;
    package.distribution = spec.distribution;
    package.vendor = spec.vendor;
    package.buildHost = spec.buildHost;
    package.fileCount = spec.fileCount;
    package.files = spec.files;

    rpmdbAddPackage(db, &package, header.spec);
    rpmdbAddGroup(db, package.name, header.group);


    /* update the files in other packages that have been overwritten */
    BeginStepHashTable(conflictingPackages);
    while (IterStepHashTable(conflictingPackages, &labelstr, 
			     (void **) &labelptr)) {
	rpmdbGetPackageInfo(db, *labelptr, &package);

	if (!strcmp(labelstr, newPackageLabelStr)) continue;

	for (i = 0; i < package.fileCount; i++) {
	    if ((fileinfo = SearchHashTable(newFiles, package.files[i].path))
		 && strcmp(package.files[i].md5, fileinfo->md5)) {
		    message(MESS_DEBUG, "%s from %s has been replaced\n", 
			    package.files[i].path, package.labelstr);
		    package.files[i].state = RPMFILE_STATE_REPLACED;
	    }
	}

	rpmdbUpdatePackage(db, &package);
    }

    FreeHashTable(conflictingPackages);
    FreeHashTable(newFiles);
    free(newPackageLabelStr);
    hdrSpecFree(&spec);
    hdrFree(&header);

    return;
}

HashTable findConflictingPackages(struct rpmdb * db, 
				  struct rpmHeaderSpec spec) {
    int i;
    struct rpmdbLabel * list, * label, * tmp;
    HashTable table;
    char * labelstr;
    
    table = CreateHashTable(10, sizeof(struct rpmdbLabel *), FALSE, FALSE);

    for (i = 0; i < spec.fileCount; i++) {
	list = rpmdbFindPackagesByFile(db, spec.files[i].path);
	if (!list) continue;

	label = list;
	while (label) {
	    labelstr = rpmdbLabelToLabelstr(*label, 0);
	    if (!SearchHashTable(table, labelstr)) {
		if (!AddToHashTable(table, labelstr, label)) 
		    message(MESS_FATALERROR, "out of memory");
		label = label->next;
	    } else {
		free(labelstr);
		rpmdbFreeLabel(*label);
		tmp = label->next;
		free(label);
		label = tmp;
	    }
	}
    }

    return table;
}

static int mymkdir(char * path, int test) {
    if (test) {
	message(MESS_DEBUG, "would mkdir(%s, 0755)\n", path);
    } else if (mkdir(path, 0755)) {
	message(MESS_ERROR, "cannot create dir: %s: %s\n", path, 
		strerror(errno));
	return -1;
    }

    return 0;
}

static int myunlink(char * path, int test) {
    if (test) {
	message(MESS_DEBUG, "would unlink(%s)\n", path);
    } else if (unlink(path)) {
	message(MESS_ERROR, "cannot remove %s: %s: %s\n", path, 
		strerror(errno));
	return -1;
    }
   
    return 0;
}

static int myrename(char * path, char * newpath, int test) {
    if (test) {
	message(MESS_DEBUG, "would rename(%s, %s)\n", path, newpath);
    } else if (rename(path, newpath)) {
	message(MESS_ERROR, "cannot rename(%s, %s): %s: %s\n", path, newpath,
		strerror(errno));
	return -1;
    }
   
    return 0;
}
