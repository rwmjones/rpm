# RPM Package Management System
# Copyright (C) 1995 Red Hat, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

# -*-perl-*-

# this was modified from the perl library Getopts

# pass in the ARGV array
# return "leftover" arguments
# continue processing through a non '-*' argument
# return all unprocessed arguments
# don't fail on unrecognized "arguments"

$rpm_getopts_errs = 0;

sub rpm_getopts {
    local($argumentative, @ARGV) = @_;
    local(@args,$_,$first,$rest);
    local(@leftovers);
    local($[) = 0;

    $rpm_getopts_errs = 0;
    @leftovers = ();
    @args = split( / */, $argumentative );
    while(@ARGV) {
	if (! (($_ = $ARGV[0]) =~ /^-(.)(.*)/)) {
	    push(@leftovers, $_);
	    shift(@ARGV);
	    next;
	}
	($first,$rest) = ($1,$2);
	$pos = index($argumentative,$first);
	if($pos >= $[) {
	    if($args[$pos+1] eq ':') {
		shift(@ARGV);
		if($rest eq '') {
		    ++$rpm_getopts_errs unless @ARGV;
		    $rest = shift(@ARGV);
		}
		eval "\$lopt_$first = \$rest;";
	    }
	    else {
		eval "\$lopt_$first += 1";
		if($rest eq '') {
		    shift(@ARGV);
		}
		else {
		    $ARGV[0] = "-$rest";
		}
	    }
	}
	else {
	    push(@leftovers, $_);
	    shift(@ARGV);
	}
    }
    return @leftovers;
}

1;
