# RPM Package Management System -*-perl-*-
# Copyright (C) 1995 Red Hat, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

sub readopts {
    local ($rcfile) = @_;
    local ($option, $rest, $orig);
    local ($arch, $flags);

    &debug("reading options from $rcfile");

    open(RCFILE, "<$rcfile") || error("Cannot open $rcfile for reading");
    while (<RCFILE>) {
	chop;

	$orig = $_;
	s/^  *//;
	s/  *$//;

	$_ || next;

	if (($option, $rest) = /^([^:]*):(.*)$/) {
	    $option =~ s/  *$//;
	    $rest =~ s/^  *//;
	    
	    if ($option eq "optflags") {
		if (!(($arch, $flags) = ($rest =~ /^([^ ]+)  *(.*)$/))) {
		    &error("bad line $orig in $rcfile");
		}
		&debug("\$optflags{$arch} set to \"$flags\"");
		$optflags{$arch} = $flags;
	    } elsif ($option eq "search") {
		push(@rpmsearchpath, $rest);
	    } elsif ($inrcfile{$option}) {
		&debug("\$rpm{$option} changed from $rpm{$option} to $rest");
		$rpm{$option} = $rest;
	    } else {
		&warning("unknown option $option in $rcfile");
	    }
	} else {
	    &warning("bad line $orig in $rcfile");
	}
    }
}

$inrcfile{"topdir"} = 1;
$inrcfile{"specdir"} = 1;
$inrcfile{"builddir"} = 1;
$inrcfile{"sourcedir"} = 1;
$inrcfile{"rpmdir"} = 1;
$inrcfile{"srcrpmdir"} = 1;
$inrcfile{"arch_sensitive"} = 1;
$inrcfile{"docdir"} = 1;
$inrcfile{"libdir"} = 1;
$inrcfile{"force"} = 1;
$inrcfile{"require_vendor"} = 1;
$inrcfile{"require_distribution"} = 1;
$inrcfile{"require_icon"} = 1;
$inrcfile{"require_group"} = 1;
$inrcfile{"timecheck"} = 1;
$inrcfile{"distribution"} = 1;
$inrcfile{"vendor"} = 1;
$inrcfile{"messagelevel"} = 1;

1;
