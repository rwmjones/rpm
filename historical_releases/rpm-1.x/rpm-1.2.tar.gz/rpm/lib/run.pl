
sub run_script {
    local ( $script ) = @_;
    local ( $pid, $of, $pre );

    $pre = &tempname();

    # Write the script
    if ($rpm{'root'}) {
	$of = $rpm{'root'} . $pre;
    } else {
	$of = $pre;
    }
    open(FD, ">$of") || &error("couldn't write $w script");
    print FD $script, "\n";
    close FD;
    chmod(0700, $of);

    # Fork it and exec it
    (($pid = fork()) < 0) && &error("couldn't fork $w script");
    if (! $pid) {
	if ($rpm{'root'}) {
	    chroot($rpm{'root'}) || &error("couldn't chroot");
	    chdir('/');
	}
	if (&isdebug()) {
	    exec "/bin/sh", "-x", "-c", $pre;
	} else {
	    exec "/bin/sh", $pre;
	}
    }

    wait;

    if ($?) {
	&warning("$w returned non-zero exit code");
	return 1;
    }

    return 0
}

sub run_prepost {
    local ( *pspec, $w ) = @_;
    local ( $pid, $of, $pre );

    if (!length($pspec{"$w:0"})) { return; }

    &run_script($pspec{"$w:0"})
}

1;
