# RPM Package Management System
# Copyright (C) 1995 Red Hat, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

# -*-perl-*-

# misc messaging functions

sub incmessagelevel {
    $rpm{"messagelevel"}++;
}

sub setmessagelevel {
    local($newlevel) = @_;
    $rpm{"messagelevel"} = $newlevel;
}

sub mess {
    local($level, @rest) = @_;
    print(@rest, "\n") if $rpm{"messagelevel"} >= $level;
}

sub debug {
    local(@rest) = @_;
    &mess(3, "D: ", @rest);
}

sub verbose {
    local(@rest) = @_;
    &mess(2, @rest);
}

sub normal {
    local(@rest) = @_;
    &mess(1, @rest);
}

sub setmessagequiet { &setmessagelevel(0); }
sub setmessageverbose { &setmessagelevel(2); }
sub setmessagedebug { &setmessagelevel(3); }

sub isquiet { return ($rpm{"messagelevel"} == 0); }
sub isverbose { return ($rpm{"messagelevel"} >= 2); }
sub isdebug { return ($rpm{"messagelevel"} >= 3); }

sub warning {
    print STDERR ("warning: ", @_, "\n") if $rpm{"messagelevel"} >= $level;
    #&normal("warning: ", @_ );
}

sub error {
    if (! $rpm{"keeptemps"}) {
	&remove_temps;
    }
    die ("error: ", @_, "\n");
}

1;
