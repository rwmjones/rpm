#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "messages.h"
#include "misc.h"
#include "rpmdb.h"

static int labelstrlistToLabelList(char * str, int length, 
				   struct rpmdbLabel ** list);
static char * rpmdbLabelListToStr(struct rpmdbLabel * list, int withFileNum);
static int addFileList(char * spec, struct rpmdbPackageInfo * pinfo);

static char * prefix = "/var/lib/rpm";

static char * rpmdbLabelListToStr(struct rpmdbLabel * list, int withFileNum) {
    char * liststr;
    char * part;
    struct rpmdbLabel * label;
    int i;
    int bytesAlloced;
    int currLength;
    int newLength;

    for (i = 0, label = list; label; i++, label = label->next) ;
    if (!i) return NULL;

    bytesAlloced = i * 20;
    liststr = malloc(bytesAlloced);
    if (!liststr) 
	message(MESS_FATALERROR, "out of memory\n");
    *liststr = '\0';

    currLength = 0;
    for (label = list; label; label = label->next, i--) {
	part = rpmdbLabelToLabelstr(*label, withFileNum);
	newLength = strlen(part);
	if ((newLength + currLength + 2) > bytesAlloced) {
	    bytesAlloced = (newLength + currLength + 2) * (i * 20);
	    liststr = realloc(liststr, bytesAlloced);
	    if (!liststr) 
		message(MESS_FATALERROR, "out of memory\n");
	}
	if (*liststr) {
	    strcat(liststr, " ");
	    strcat(liststr, part);
	} else 
	    strcpy(liststr, part);
	free(part);
    }

    return liststr;
}

char * rpmdbLabelToLabelstr(struct rpmdbLabel label, int withFileNum) {
    char * c;
    char buffer[50];
 
    if (withFileNum && label.fileNumber > -1) 
	c = malloc(strlen(label.name) + strlen(label.version) + 
		   strlen(label.release) + 10);
    else
	c = malloc(strlen(label.name) + strlen(label.version) + 
		   strlen(label.release) + 3);
    if (!c) 
	message(MESS_FATALERROR, "out of memory\n");

    strcpy(c, label.name);
    strcat(c, ":");
    strcat(c, label.version);
    strcat(c, ":");
    strcat(c, label.release);

    if (withFileNum && label.fileNumber > -1)  {
	sprintf(buffer, "%d", label.fileNumber);
	strcat(c, ":");
	strcat(c, buffer);
    }

    return c;
}

int rpmdbLabelstrToLabel(char * str, int length, struct rpmdbLabel * label) {
    char * chptr;

    label->freeType = RPMDB_FREENAME;
    label->next = NULL;
    label->name = malloc(length + 1);
    if (!label->name) {
	return 1;
    }
    memcpy(label->name, str, length);
    label->name[length] = '\0';

    chptr = label->name;
    while (*chptr != ':') chptr++;
    *chptr = '\0';
    label->version = ++chptr;
    while (*chptr != ':') chptr++;
    *chptr = '\0';
    label->release = chptr + 1;

    label->fileNumber = -1;

    /* there might be a path number tagged on to the end of this */
    while ((chptr - label->name) < length && *chptr != ':') chptr++;
    if ((chptr - label->name) < length) {
	*chptr = '\0';
	label->fileNumber = atoi(chptr + 1);
    }

    return 0;
}

static int labelstrlistToLabelList(char * str, int length, 
				   struct rpmdbLabel ** list) {
    char * start, * chptr;
    struct rpmdbLabel * head = NULL;
    struct rpmdbLabel * tail, * label;
    
    start = str;
    for (chptr = start; (chptr - str) < length; chptr++) {
	/* spaces following a space get ignored */
	if (*chptr == ' ' && start < chptr) {
	    label = malloc(sizeof(struct rpmdbLabel));
	    if (!label) {
		rpmdbFreeLabelList(head);
		return 1;
	    }
	    if (rpmdbLabelstrToLabel(start, chptr - start, label)) {
		free(label);
		rpmdbFreeLabelList(head);
		return 1;
	    }

	    if (!head) {
		head = label;
		tail = label;
	    } else {
		tail->next = label;
		tail = tail->next;
	    }

	    start = chptr + 1;
	}
    }

    /* a space on the end would break things horribly w/o this test */
    if (start < chptr) {
	label = malloc(sizeof(struct rpmdbLabel));
	if (!label) {
	    rpmdbFreeLabelList(head);
	    return 1;
	}
	if (rpmdbLabelstrToLabel(start, chptr - start, label)) {
	    free(label);
	    rpmdbFreeLabelList(head);
	    return 1;
	}

	if (!head) {
	    head = label;
	    tail = label;
	} else {
	    tail->next = label;
	    tail = tail->next;
	}

	start = chptr + 1;
    }

    *list = head;
    return 0;
}

void rpmdbOpen(int openFlags, struct rpmdb * rpmdb) {
    unsigned int gdbmFlags = 0;
    char path[255];

    rpmdb->rpmdbError = RPMDB_NONE;

    if (openFlags & RPMDB_READER)
	gdbmFlags |= GDBM_READER;
    if (openFlags & RPMDB_WRITER)
	gdbmFlags |= GDBM_WRCREAT;

    strcpy(path, prefix);
    strcat(path, "/packages");
    rpmdb->packages = gdbm_open(path, 1024, gdbmFlags, 0644, NULL);
    if (!rpmdb->packages)
	message(MESS_FATALERROR, "cannot open %s: %s\n", path, 
		gdbm_strerror(gdbm_errno));

    strcpy(path, prefix);
    strcat(path, "/nameidx");
    rpmdb->nameIndex = gdbm_open(path, 1024, gdbmFlags, 0644, NULL);
    if (!rpmdb->packages)
	message(MESS_FATALERROR, "cannot open %s: %s\n", path, 
		gdbm_strerror(gdbm_errno));

    strcpy(path, prefix);
    strcat(path, "/pathidx");
    rpmdb->pathIndex = gdbm_open(path, 1024, gdbmFlags, 0644, NULL);
    if (!rpmdb->packages)
	message(MESS_FATALERROR, "cannot open %s: %s\n", path, 
		gdbm_strerror(gdbm_errno));

    strcpy(path, prefix);
    strcat(path, "/iconidx");
    rpmdb->iconIndex = gdbm_open(path, 1024, gdbmFlags, 0644, NULL);
    if (!rpmdb->packages)
	message(MESS_FATALERROR, "cannot open %s: %s\n", path, 
		gdbm_strerror(gdbm_errno));

    strcpy(path, prefix);
    strcat(path, "/groupindex");
    rpmdb->groupIndex = gdbm_open(path, 1024, gdbmFlags, 0644, NULL);
    if (!rpmdb->packages)
	message(MESS_FATALERROR, "cannot open %s: %s\n", path, 
		gdbm_strerror(gdbm_errno));

    strcpy(path, prefix);
    strcat(path, "/postidx");
    rpmdb->postIndex = gdbm_open(path, 1024, gdbmFlags, 0644, NULL);
    if (!rpmdb->packages)
	message(MESS_FATALERROR, "cannot open %s: %s\n", path, 
		gdbm_strerror(gdbm_errno));
}

void rpmdbClose(struct rpmdb * rpmdb) {
    gdbm_close(rpmdb->packages);
    gdbm_close(rpmdb->nameIndex);
    gdbm_close(rpmdb->pathIndex);
}

struct rpmdbLabel * rpmdbGetAllLabels(struct rpmdb * rpmdb) {
    datum rec;

    struct rpmdbLabel * head = NULL;
    struct rpmdbLabel * tail = NULL;
    struct rpmdbLabel * label;

    rpmdb->rpmdbError = RPMDB_NONE;

    rec = gdbm_firstkey(rpmdb->packages);
    while (rec.dptr) {
	label = malloc(sizeof(struct rpmdbLabel));
	if (!label) {
	    rpmdbFreeLabelList(head);
	    rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	    return NULL;
	}
	if (rpmdbLabelstrToLabel(rec.dptr, rec.dsize, label)) {
	    free(label);
	    rpmdbFreeLabelList(head);
	    rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	    return NULL;
	}

	if (!head) {
	    head = label;
	    tail = label;
	} else {
	    tail->next = label;
	    tail = tail->next;
	}

	rec = gdbm_nextkey(rpmdb->packages, rec);
    }

    return head;
}

struct rpmdbLabel * rpmdbFindPackagesByFile(struct rpmdb * rpmdb, char * path) {
    datum rec;
    datum key;
    struct rpmdbLabel * list;

    rpmdb->rpmdbError = RPMDB_NONE;

    key.dptr = path;
    key.dsize = strlen(path);
    rec = gdbm_fetch(rpmdb->pathIndex, key);
    
    if (!rec.dptr) 
	return NULL;
    if (labelstrlistToLabelList(rec.dptr, rec.dsize, &list)) {
	free(rec.dptr);
	rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	return NULL;
    }
    free(rec.dptr);

    return list;
}

struct rpmdbLabel * rpmdbFindPackagesByLabel(struct rpmdb * rpmdb, 
					     struct rpmdbLabel label)

/* the Name has to be here. The version/release fields optionally
   restrict the search. Either will do. */

{
    datum rec;
    datum key;
    struct rpmdbLabel * list;
    struct rpmdbLabel * prospect;
    struct rpmdbLabel * parent;
    int bad;

    rpmdb->rpmdbError = RPMDB_NONE;

    key.dptr = label.name;
    key.dsize = strlen(label.name);
    rec = gdbm_fetch(rpmdb->nameIndex, key);
    
    if (!rec.dptr) 
	return NULL;
    if (labelstrlistToLabelList(rec.dptr, rec.dsize, &list)) {
	free(rec.dptr);
	rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	return NULL;
    }
    free(rec.dptr);

    prospect = list;
    parent = NULL;
    while (prospect) {
	bad = 0;
	if (label.version && strcmp(label.version, prospect->version))
	    bad = 1;
	else if (label.release && strcmp(label.release, prospect->release))
	    bad = 1;

	if (bad) {
	    rpmdbFreeLabel(*prospect);
	    if (!parent) {
		list = prospect->next;
		free(prospect);
		prospect = list;
	    } else {
		parent->next = prospect->next;
		free(prospect);
		prospect = parent->next;
	    }
	} else {
	    prospect = prospect->next;
	}
    }

    return list;
}

struct rpmdbLabel rpmdbMakeLabel(char * name, char * version, char * release,
				 int fileNumber, enum rpmdbFreeType freeType) {
    struct rpmdbLabel label;

    label.next = NULL;
    label.freeType = freeType;
    label.name = name;
    label.version = version;
    label.release = release;
    label.fileNumber = fileNumber;

    return label;
}

void rpmdbFreeLabelList(struct rpmdbLabel * list) {
    struct rpmdbLabel * saved;

    while (list) {
	rpmdbFreeLabel(*list);
	saved = list->next;
	free(list);
	list = saved;
    }
}

void rpmdbFreeLabel(struct rpmdbLabel label) {
    if (label.freeType == RPMDB_NOFREE) return;

    free(label.name);
    if (label.freeType == RPMDB_FREEALL) {
	free(label.version);
	free(label.release);
    }
}

char * rpmdbGetPackageGroup(struct rpmdb * rpmdb, struct rpmdbLabel label) {
    datum key, rec;
    
    key.dptr = label.name;
    key.dsize = strlen(label.name);
    
    rec = gdbm_fetch(rpmdb->groupIndex, key);
    if (!rec.dptr)
	rec.dptr = strdup("Unknown");

    return rec.dptr;
}

int rpmdbGetPackageInfo(struct rpmdb * rpmdb, struct rpmdbLabel label,
			struct rpmdbPackageInfo * pinfo) {
    char * labelstr;
    char ** list, ** prelist;
    char ** strptr;
    datum key, rec;
    int i, j;

    labelstr = rpmdbLabelToLabelstr(label, 0);

    message(MESS_DEBUG, "pulling %s from database\n", labelstr);

    key.dptr = labelstr;
    key.dsize = strlen(labelstr);
    
    rec = gdbm_fetch(rpmdb->packages, key);
    if (!rec.dptr)
	message(MESS_FATALERROR, "error: package %s not found in database "
		"(which is probably corrupt)\n", labelstr);

    free(labelstr);

    list = splitString(rec.dptr, rec.dsize, '\1');
    free(rec.dptr);

    /* these strdup's should be checked! */

    pinfo->version = strdup(list[1]); 
    pinfo->release = strdup(list[2]); 
    if (strcmp(list[3], "1")) {
	message(MESS_FATALERROR, "error: extremely old databases not supported by C rpm\n");
	exit(1);
    }
    pinfo->name = malloc(strlen(list[0]) + strlen(list[4]) + 2);
    strcpy(pinfo->name, list[0]);
    if (strlen(list[4])) {
	strcat(pinfo->name, "-");
	strcat(pinfo->name, list[4]);
    }
    pinfo->labelstr = malloc(strlen(pinfo->name) + strlen(pinfo->version) +
			     strlen(pinfo->release) + 3);
    strcpy(pinfo->labelstr, pinfo->name);
    strcat(pinfo->labelstr, ":");
    strcat(pinfo->labelstr, pinfo->version);
    strcat(pinfo->labelstr, ":");
    strcat(pinfo->labelstr, pinfo->release);

    pinfo->preamble = strdup(list[5]);
    pinfo->installTime = atoi(list[6]);
    pinfo->fileCount = atoi(list[7]);
    
    prelist = splitString(pinfo->preamble, strlen(pinfo->preamble), '\n');
    if (!prelist) {
	freeSplitString(list);
	rpmdb->rpmdbError = RPMDB_NO_MEMORY;
	return 1;
    }

    /* these are optional */
    pinfo->distribution = NULL;
    pinfo->vendor = NULL;
    pinfo->description = NULL;

    for (strptr = prelist; *strptr; strptr++) {
	if (!strncmp("Description: ", *strptr, 13))
	    pinfo->description = strdup((*strptr) + 13);
	else if (!strncmp("Distribution: ", *strptr, 14))
	    pinfo->distribution = strdup((*strptr) + 14);
	else if (!strncmp("Vendor: ", *strptr, 8))
	    pinfo->vendor = strdup((*strptr) + 8);
	else if (!strncmp("size: ", *strptr, 6))
	    pinfo->size = atoi((*strptr) + 6);
	else if (!strncmp("BuildTime: ", *strptr, 11))
	    pinfo->buildTime =atoi((*strptr) + 11);
	else if (!strncmp("BuildHost: ", *strptr, 11))
	    pinfo->buildHost = strdup((*strptr) + 11);
    }
    freeSplitString(prelist);

    if (!pinfo->vendor) pinfo->vendor = strdup("");
    if (!pinfo->description) pinfo->description = strdup("");
    if (!pinfo->distribution) pinfo->distribution = strdup("");

    pinfo->files = malloc(sizeof(struct rpmFileInfo) * pinfo->fileCount);
    if (!pinfo->files)
	message(MESS_FATALERROR, "out of memory\n");

    j = 8;
    for (i = 0; i < pinfo->fileCount; i++) {
	rpmfileFromInfoLine(list[j], list[j + 1], list[j + 2],
			    &pinfo->files[i]);
	j += 3;
    }

    freeSplitString(list);
		
    return 0;
}

void rpmdbFreePackageInfo(struct rpmdbPackageInfo package) {
    int i;

    free(package.version);
    free(package.release);
    free(package.name);
    free(package.labelstr);
    free(package.buildHost);
    free(package.vendor);
    free(package.description);
    free(package.distribution);
    free(package.preamble);

    for (i = 0; i < package.fileCount; i++) {
	rpmfileFree(&package.files[i]);
    }

    free(package.files);
}

const char * rpmdbStrerror(struct rpmdb * rpmdb) {
    switch (rpmdb->rpmdbError) {
      case RPMDB_NONE:
	return "none";
      case RPMDB_GDBM_ERROR:
	return gdbm_strerror(rpmdb->gdbmError);
      case RPMDB_NO_MEMORY:
	return "out of memory";
    }

    return "unknown error";
}

int rpmdbWasError(struct rpmdb * rpmdb) {
    return (rpmdb->rpmdbError != RPMDB_NONE);
}

int rpmdbLabelCmp(struct rpmdbLabel * one, struct rpmdbLabel * two) {
    int i;

    if ((i = strcmp(one->name, two->name)))
	return i;
    else if ((i = strcmp(one->version, two->version)))
	return i;
    else
	return strcmp(one->release, two->release);
}

void rpmdbUpdateFilelist(struct rpmdb * rpmdb, char * path, 
			 struct rpmdbLabel * list)
{
    char * liststr;
    datum key, item;

    key.dptr = path;
    key.dsize = strlen(path);

    if (list) {
	liststr = rpmdbLabelListToStr(list, 1);
	message(MESS_DEBUG, "path list for %s now %s\n", path, liststr);
	
	item.dptr = liststr;
	item.dsize = strlen(liststr);
	if (gdbm_store(rpmdb->pathIndex, key, item, GDBM_REPLACE)) 
	    message(MESS_ERROR, "cannot update pathindex: %s\n",
		    gdbm_strerror(gdbm_errno));

	free(liststr);
    } else {
	message(MESS_DEBUG, "removing path list for %s\n", path);
	gdbm_delete(rpmdb->pathIndex, key);
    }
}

void rpmdbUpdateNamelist(struct rpmdb * rpmdb, char * name, 
			 struct rpmdbLabel * list)
{
    char * liststr;
    datum key, item;

    key.dptr = name;
    key.dsize = strlen(name);

    if (list) {
	liststr = rpmdbLabelListToStr(list, 0);
	message(MESS_DEBUG, "name list for %s now %s\n", name, liststr);
	
	item.dptr = liststr;
	item.dsize = strlen(liststr);
	if (gdbm_store(rpmdb->nameIndex, key, item, GDBM_REPLACE)) 
	    message(MESS_ERROR, "cannot update nameindex: %s\n",
		    gdbm_strerror(gdbm_errno));

	free(liststr);
    } else {
	message(MESS_DEBUG, "removing name list for %s\n", name);
	if (gdbm_delete(rpmdb->nameIndex, key))
	    message(MESS_ERROR, "cannot delete nameindex: %s\n",
		    gdbm_strerror(gdbm_errno));
    }
}

void rpmdbRemoveIcon(struct rpmdb * rpmdb, char * label) {
    datum key;

    key.dptr = label;
    key.dsize = strlen(label);

    /* it's okay if no icon exists */
    gdbm_delete(rpmdb->iconIndex, key);
}

void rpmdbRemoveGroup(struct rpmdb * rpmdb, char * label) {
    /* we don't remove groups, though perhaps we should ***/
}

void rpmdbRemovePackageEntry(struct rpmdb * rpmdb, char * label) {
    datum key;

    key.dptr = label;
    key.dsize = strlen(label);

    if (gdbm_delete(rpmdb->packages, key))
	message(MESS_ERROR, "cannot delete package index: %s\n",
		gdbm_strerror(gdbm_errno));
}

void rpmdbRemoveScripts(struct rpmdb * rpmdb, char * label) {
    datum key;
    char * buf;

    buf = malloc(strlen(label) + 6);
    if (!buf) {
	message(MESS_FATALERROR, "out of memory");
    }

    strcpy(buf, label);
    strcat(buf, "pre");

    key.dptr = buf;
    key.dsize = strlen(buf);

    /* it's okay if no pre uninstall script exists */
    gdbm_delete(rpmdb->postIndex, key);

    strcpy(buf, label);
    strcat(buf, "post");

    key.dptr = buf;
    key.dsize = strlen(buf);

    /* it's okay if no post uninstall script exists */
    gdbm_delete(rpmdb->postIndex, key);

    free(buf);
}

static int addFileList(char * str, struct rpmdbPackageInfo * pinfo) {
    int i;
    int size = 0;
    char * chptr;

    for (i = 0; i < pinfo->fileCount; i++) {
	strcat(str, "\1");
	strcat(str, pinfo->files[i].path);
	strcat(str, "\1");
	strcat(str, rpmfileStateStrs[pinfo->files[i].state]);
	strcat(str, "\1");
	chptr = rpmfileToInfoStr(&pinfo->files[i]);
	strcat(str, chptr);

	size += 3 + strlen(pinfo->files[i].path) + strlen(chptr) +
		strlen(rpmfileStateStrs[pinfo->files[i].state]);

	free(chptr);
    }

    return size;
}

/* a lot like update, but the preamble is in pinfo already */
void rpmdbUpdatePackage(struct rpmdb * rpmdb, struct rpmdbPackageInfo * pinfo) {
    int size, i;
    char * str;
    datum key, item;
   
    /* get a quick estimate of how big this is -- it comes out a bit 
       too large, but that's okay */

    size = strlen(pinfo->name) + strlen(pinfo->version) + 
		  strlen(pinfo->release) + 1 + 5;
    size += 1 + strlen(pinfo->preamble) + 1 + 20 + 10;

    for (i = 0; i < pinfo->fileCount; i++) {
	size += strlen(pinfo->files[i].path) + 80;
	if (pinfo->files[i].linkto) 
	    size += strlen(pinfo->files[i].linkto);
    }

    str = malloc(size);
    if (!str)
	message(MESS_FATALERROR, "out of memory");
    size = sprintf(str, "%s\1%s\1%s\1%s\1\1%s\1%d\1%d", pinfo->name, 
		   pinfo->version, pinfo->release, "1", pinfo->preamble,
    		   pinfo->installTime, pinfo->fileCount);

    size += addFileList(str, pinfo);

    item.dptr = str;
    item.dsize = size;

    key.dptr = pinfo->labelstr;
    key.dsize = strlen(pinfo->labelstr);

    if (gdbm_store(rpmdb->packages, key, item, GDBM_REPLACE)) 
	message(MESS_ERROR, "cannot update package: %s\n",
		gdbm_strerror(gdbm_errno));

    free(str);
}

void rpmdbAddPackage(struct rpmdb * rpmdb, struct rpmdbPackageInfo * pinfo,
		    char * spec) {
    char * str;
    int size;
    char * chptr;
    int i;
    char buf[50];
    datum key, item;

    /* get a quick estimate of how big this is -- it comes out a bit 
       too large, but that's okay */

    size = strlen(pinfo->name) + strlen(pinfo->version) + 
		  strlen(pinfo->release) + 1 + 5;
    
    chptr = strstr(spec, "\n%speci");
    if (!chptr)
	message(MESS_FATALERROR, "bad spec in rpmdbAddPackage()");
    
    size += 1 + (chptr - spec) + 1 + 20 + 10;

    for (i = 0; i < pinfo->fileCount; i++) {
	size += strlen(pinfo->files[i].path) + 80;
	if (pinfo->files[i].linkto) 
	    size += strlen(pinfo->files[i].linkto);
    }

    str = malloc(size);
    if (!str)
	message(MESS_FATALERROR, "out of memory");
    size = sprintf(str, "%s\1%s\1%s\1%s\1\1", pinfo->name, pinfo->version, 
		        pinfo->release, "1");
    strncat(str, spec, (chptr - spec));
    size += (chptr - spec);
    strcat(str, "\1");
    size += sprintf(buf, "%d\1%d", pinfo->installTime, pinfo->fileCount);
    strcat(str, buf);

    size += addFileList(str, pinfo);
    
    item.dptr = str;
    item.dsize = size;

    key.dptr = pinfo->labelstr;
    key.dsize = strlen(pinfo->labelstr);

    if (gdbm_store(rpmdb->packages, key, item, GDBM_INSERT)) 
	message(MESS_ERROR, "cannot create package: %s\n",
		gdbm_strerror(gdbm_errno));

    free(str);
}

void rpmdbAddGroup(struct rpmdb * rpmdb, char * name, char * group) {
    datum key, item;
    
    item.dptr = group;
    item.dsize = strlen(group);

    key.dptr = name;
    key.dsize = strlen(name);

    if (gdbm_store(rpmdb->groupIndex, key, item, GDBM_REPLACE)) 
	message(MESS_ERROR, "cannot update group index for: %s\n",
		gdbm_strerror(gdbm_errno));
}

void rpmdbSetPrefix(char * new) {
    prefix = new;
}
