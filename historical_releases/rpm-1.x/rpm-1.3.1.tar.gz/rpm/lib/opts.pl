# RPM Package Management System
# Copyright (C) 1995 Red Hat, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

# -*-perl-*-

require "readopts.pl";

$rpm{"version"} = "1.3.1";
$rpm{"copyright"} = "Copyright (C) 1995 - Red Hat Software
This may be freely redistributed under the terms of the GNU Public License";
$rpm{"options"} = "";

$rpm{"rcfile"} = "rpmrc";
$rpm{"topdir" } ="/usr/src";
$rpm{"arch_sensitive"} = 0;
$rpm{"docdir"} = "/usr/doc";
$rpm{"binext"} = ".rpm";
$rpm{"srcext"} = ".src.rpm";
$rpm{"specext"} = ".spec";
$rpm{"libdir"} = "/var/lib/rpm";
$rpm{"percent"} = 0;
$rpm{"force"} = 0;
$rpm{"require_vendor"} = 0;
$rpm{"require_distribution"} = 0;
$rpm{"require_icon"} = 0;
$rpm{"require_group"} = 0;
$rpm{"keeptemps"} = 0;
$rpm{"timecheck"} = 7200;
# $rpm{"distribution"};
# $rpm{"vendor"};
# $rpm{"root"};

# 0 = quiet
# 1 = default
# 2 = verbose
# 3 = debug
$rpm{"messagelevel"} = 1;

$rpm{"clean"} = 0;
$rpm{"short_circuit"} = 0;

$rpm{"PATH"} = "/bin:/usr/bin:/sbin:/usr/sbin:/usr/bin/X11";
$rpm{"DOCPATH"} = "/usr/doc:/usr/man:/usr/info:/usr/X11R6/man";

# Now load any rc files

if (-f "/etc/$rpm{'rcfile'}") {
    &readopts("/etc/$rpm{'rcfile'}");
}

if (-f "$ENV{'HOME'}/.$rpm{'rcfile'}") {
    &readopts("$ENV{'HOME'}/.$rpm{'rcfile'}");
}

if (! $rpm{specdir} ) {
    $rpm{"specdir"} = $rpm{topdir} . "/SPECS";
}
if (! $rpm{builddir} ) {
    $rpm{"builddir"} = $rpm{topdir} . "/BUILD";
}
if (! $rpm{sourcedir} ) {
    $rpm{"sourcedir"} = $rpm{topdir} . "/SOURCES";
}
if (! $rpm{rpmdir} ) {
    $rpm{"rpmdir"} = $rpm{topdir} . "/RPMS";
}
if (! $rpm{srcrpmdir} ) {
    $rpm{"srcrpmdir"} = $rpm{topdir} . "/SRPMS";
}

1;
