#include <endian.h>
#include <errno.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "header.h"
#include "misc.h"
#include "rpmfile.h"

/* This *can't* read 1.0 headers -- it needs 1.1 (w/ group and icon fields)
   or better. I'd be surprised if any 1.0 headers are left anywhere anyway.
   Red Hat 2.0 shipped with 1.1 headers, but some old BETAs used 1.0. */

struct literalHeader {
    unsigned char m1, m2, m3, m4;
    unsigned char major, minor;

    unsigned short type, cpu;
    char labelstr[66];
    unsigned int specOffset;
    unsigned int specLength;
    unsigned int archiveOffset;
    unsigned int size;
    unsigned int os;
    unsigned int groupLength;
    unsigned int iconLength;
} ;

/* this leaves the file pointer pointing at the data section */

char * hdrReadFromStream(FILE * f, struct rpmHeader * header) {
    struct literalHeader lit;
    char * chptr;
    int bytesRead;
    char ch;
    unsigned int specOffset;
    unsigned int archiveOffset;
    unsigned int groupLength;

    if (fread(&lit, sizeof(lit), 1, f) != 1) {
	return strerror(errno);
    }

    bytesRead = sizeof(lit);

    if (lit.m1 != 0xed || lit.m2 != 0xab || lit.m3 != 0xee ||
	lit.m4 != 0xdb) {
	return "bad magic for RPM package";
    }

    specOffset = htonl(lit.specOffset);
    header->specLength = htonl(lit.specLength);
    archiveOffset = htonl(lit.archiveOffset);
    header->size = htonl(lit.size);
    header->os = htonl(lit.os);
    groupLength = htonl(lit.groupLength);
    header->iconLength = htonl(lit.iconLength);

    header->spec = malloc(header->specLength);
    header->name = malloc(strlen(lit.labelstr) + 1);
    if (!header->spec || !header->name) {
	header->spec ? free(header->spec) : 0;
	header->name ? free(header->name) : 0;
	return "out of memory";
    }

    strcpy(header->name, lit.labelstr);
    chptr = header->name + strlen(header->name);
    while (*chptr != '-') chptr--;
    *chptr = '\0';
    header->release = chptr + 1;
    while (*chptr != '-') chptr--;
    *chptr = '\0';
    header->version = chptr + 1;

    if (groupLength) {
        header->group = malloc(groupLength);
	if (!header->group) {
	    free(header->spec);
	    free(header->name);
	    return "out of memory";
	}

	if (fread(header->group, groupLength, 1, f) != 1) {
	    hdrFree(header);
	    return strerror(errno);
	}
	bytesRead += groupLength;
    } else {
	header->group = NULL;
    }
	
    if (header->iconLength) {
	header->icon = malloc(header->iconLength);
	if (!header->icon) {
	    free(header->spec);
	    free(header->name);
	    free(header->icon);
	    return "out of memory";
	}
	if (fread(header->icon, header->iconLength, 1, f) != 1) {
	    hdrFree(header);
	    return strerror(errno);
	}
	bytesRead += header->iconLength;
    } else {
	header->icon = NULL;
    }

    while (bytesRead < specOffset) {
	if (fread(&ch, 1, 1, f) != 1) {
	    hdrFree(header);
	    return strerror(errno);
	}
	bytesRead++;
    }

    if (fread(header->spec, header->specLength, 1, f) != 1) {
	hdrFree(header);
	return strerror(errno);
    }
    bytesRead += header->specLength;

    while (bytesRead < archiveOffset) {
	if (fread(&ch, 1, 1, f) != 1) {
	    hdrFree(header);
	    return strerror(errno);
	}
	bytesRead++;
    }

    return NULL;
}

char * hdrReadFromFile(char * filename, struct rpmHeader * header) {
    char * rc;
    FILE * f;

    f = fopen(filename, "r");
    if (!f) return strerror(errno);
    
    rc = hdrReadFromStream(f, header);
    fclose(f);
    
    return rc;
}

void hdrFree(struct rpmHeader * header) {
    free(header->name);
    free(header->spec);
    header->group ? free(header->icon) : 0;
    header->group ? free(header->group) : 0;
}

void hdrSpecFree(struct rpmHeaderSpec * spec) {
    free(spec->description);
    free(spec->vendor);
    free(spec->distribution);
    free(spec->buildHost);

    while (spec->fileCount) {
	spec->fileCount--;
	rpmfileFree(spec->files + spec->fileCount);
    }

    free(spec->files);
}

char * hdrParseSpec(struct rpmHeader * header, struct rpmHeaderSpec * spec) {
    char ** lines;
    char ** strptr;
    char ** files;
    int inFilelist = 0, i;

    lines = splitString(header->spec, header->specLength, '\n');
    if (!lines) {
	return "out of memory";
    }

    /* these are optional */
    spec->distribution = NULL;
    spec->vendor = NULL;
    spec->description = NULL;

    spec->fileCount = 0;
    for (strptr = lines; *strptr; strptr++) {
	if (inFilelist) {
	    if (**strptr) 
		spec->fileCount++;
	} else {
	    if (!strncmp("Description: ", *strptr, 13))
		spec->description = strdup((*strptr) + 13);
	    else if (!strncmp("Distribution: ", *strptr, 14))
		spec->distribution = strdup((*strptr) + 14);
	    else if (!strncmp("Vendor: ", *strptr, 8))
		spec->vendor = strdup((*strptr) + 8);
	    else if (!strncmp("BuildHost: ", *strptr, 11))
		spec->buildHost = strdup((*strptr) + 11);
	    else if (!strncmp("%speci", *strptr, 6)) {
		inFilelist = 1;
		files = strptr + 1;
	    }
	}
    }

    spec->files = malloc(sizeof(struct rpmFileInfo) * spec->fileCount);
    if (!spec->files) {
	freeSplitString(lines);
	return "out of memory";
    }

    for (strptr = files, i = 0; *strptr; strptr++, i++) {
	if (**strptr) 
	    if (rpmfileFromSpecLine(*strptr, spec->files + i)) {
		free(spec->files);
		freeSplitString(lines);
		return "out of memory";
	    }
    }

    freeSplitString(lines);

    if (!spec->vendor) spec->vendor = strdup("");
    if (!spec->description) spec->description = strdup("");
    if (!spec->distribution) spec->distribution = strdup("");

    return NULL;
}
