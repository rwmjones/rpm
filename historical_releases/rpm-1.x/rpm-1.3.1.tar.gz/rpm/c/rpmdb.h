#ifndef _H_RPMDB
#define _H_RPMDB

#include <gdbm.h>

typedef enum { RPMDB_NONE, RPMDB_GDBM_ERROR, RPMDB_NO_MEMORY } rpm_error;

struct rpmdb {
    GDBM_FILE packages;
    GDBM_FILE nameIndex;
    GDBM_FILE pathIndex;
    rpm_error rpmdbError;
    gdbm_error gdbmError;
};

enum rpmdbFreeType { RPMDB_NOFREE, RPMDB_FREENAME, RPMDB_FREEALL } ;

struct rpmdbLabel {
    char * name, * version, * release;
    enum rpmdbFreeType freeType;
    struct rpmdbLabel * next;
};

struct rpmdbPackageInfo {
    char * name, * version, * release;
    char * labelstr;
    unsigned int installTime, buildTime;
    char * group;
    unsigned int size;
    char * description;
    char * distribution;
    char * vendor;
    char * buildHost;
    unsigned int fileCount;
    struct rpmdbFileInfo * files;
} ;

struct rpmdbFileInfo {
    char * path;
    char * state;
    char * info;
} ;

#define RPMDB_READER 1
#define RPMDB_WRITER 2

int rpmdbOpen(char * prefix, int openFlags, struct rpmdb * rpmdb);
void rpmdbClose(struct rpmdb * rpmdb);
const char * rpmdbStrerror(struct rpmdb * rpmdb);
struct rpmdbLabel * rpmdbGetAllLabels(struct rpmdb * rpmdb);
struct rpmdbLabel * rpmdbFindPackagesByFile(struct rpmdb * rpmdb, char * path);
struct rpmdbLabel * rpmdbFindPackagesByLabel(struct rpmdb * rpmdb, 
					     struct rpmdbLabel label);

int rpmdbGetPackageInfo(struct rpmdb * rpmdb, struct rpmdbLabel label,
			struct rpmdbPackageInfo * pinfo);
void rpmdbFreePackageInfo(struct rpmdbPackageInfo package);

struct rpmdbLabel rpmdbMakeLabel(char * name, char * version, char * release,
				 enum rpmdbFreeType freeType);
void rpmdbFreeLabelList(struct rpmdbLabel * list);
void rpmdbFreeLabel(struct rpmdbLabel label);
int rpmdbWasError(struct rpmdb * rpmdb);

int rpmdbLabelstrToLabel(char * str, int length, struct rpmdbLabel * label);

#endif
