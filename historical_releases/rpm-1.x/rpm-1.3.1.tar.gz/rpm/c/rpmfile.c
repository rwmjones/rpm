#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "misc.h"
#include "rpmfile.h"

int rpmfileFromSpecLine(char * str, struct rpmFileInfo * fi) {
    char ** fields;

    fields = splitString(str, strlen(str), ' ');
    if (!fields) return 1;

    fi->path = strdup(fields[0]);
    if (!fi) {
	freeSplitString(fields);
	return 1;
    }

    fi->state = RPMFILE_STATE_NORMAL;
    fi->size = strtol(fields[1], NULL, 10);
    fi->mtime = strtol(fields[2], NULL, 10);
    strcpy(fi->md5, fields[3]);
    fi->mode = strtol(fields[4], NULL, 8);
    fi->uid = strtol(fields[5], NULL, 8);
    fi->gid = strtol(fields[6], NULL, 8);
    fi->isconf = fields[7][0] != '0';
    fi->isdoc = fields[8][0] != '0';
    fi->rdev = strtol(fields[9], NULL, 8);
   
    if (S_ISLNK(fi->mode)) {
	fi->linkto = strdup(fields[10]);
	if (!fi->linkto) {
	    free(fi->path);
	    freeSplitString(fields);
	    return 1;
	}
    } else {
	fi->linkto = NULL;
    }

    freeSplitString(fields);

    return 0;
}

void rpmfileFree(struct rpmFileInfo * fi) {
    free(fi->path);
    fi->linkto ? free(fi->linkto) : 0;
}
