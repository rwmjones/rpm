#ifndef H_BUILD
#define H_BUILD

int build(char *arg, int buildAmount, char *passPhrase,
	  char *buildRoot, int fromTarball, int test, char *cookie,
	  int force);

#endif
