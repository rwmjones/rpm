#ifndef H_DEPENDS
#define H_DEPENDS

#include "header.h"

int headerMatchesDepFlags(Header h, char * reqInfo, int reqFlags);

#endif
