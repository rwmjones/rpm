#ifndef H_FINDME
#define H_FINDME

char * findProgramPath(char * argv0);

#endif
