#include <fcntl.h>
#include <unistd.h>

#include "falloc.h"

struct faHeader {
    unsigned int size;
    unsigned int freeNext; /* offset of the next free block, 0 if none */
    unsigned int freePrev;
    unsigned int isFree;
};

void main(int argc, char ** argv) {
    faFile fa;
    int offset;
    struct faHeader h;

    fa = faOpen("/var/lib/rpm/packages.rpm", O_RDONLY, 0);
    if (!fa) {
	printf("couldn't open file\n");
	exit(1);
    }

    printf("Free list:\n");
    printf("      Offset        Previous      Next     Size     IsFree\n");
    printf("    ------------------------------------------------------------\n");

    offset = fa->firstFree;
    while (offset) {
	lseek(fa->fd, offset, SEEK_SET);
	read(fa->fd, &h, sizeof(h));
	printf("     %7d         %7d   %7d  %7d       %d\n",
		offset, h.freePrev, h.freeNext, h.size, h.isFree);

	offset = h.freeNext;
    }
}
