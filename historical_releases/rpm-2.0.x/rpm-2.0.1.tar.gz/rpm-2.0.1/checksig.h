#ifndef H_CHECKSIG
#define H_CHECKSIG

int doCheckSig(char **argv);

#endif
