#ifndef _H_PACKAGE
#define _H_PACKAGE

/* These use file descriptiors rather then the stdio library to insure
   no buffering takes place */

#include "header.h"

int pkgReadHeader(int fd, Header * hdr, int * isSource);
   /* 0 = success */
   /* 1 = bad magic */
   /* 2 = error */

#endif
