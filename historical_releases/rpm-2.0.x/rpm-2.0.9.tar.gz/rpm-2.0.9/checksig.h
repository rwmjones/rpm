#ifndef H_CHECKSIG
#define H_CHECKSIG

int doCheckSig(char **argv);

int doReSign(char *passPhrase, char **argv);

#endif
