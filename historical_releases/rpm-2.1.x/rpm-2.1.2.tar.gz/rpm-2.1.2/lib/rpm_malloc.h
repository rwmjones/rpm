#ifndef H_RPM_MALLOC
#define H_RPM_MALLOC

#ifndef __linux__
#error malloc definition needed for non Linux OS
#endif

#endif
