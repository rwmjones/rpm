#ifdef	HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef __STDC__
#ifndef __P
#define	__P(p)	p
#endif
#else
#ifndef __P
#define	__P(p)	()
#endif
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>

#ifdef	HAVE_SYS_SELECT_H
#include <sys/select.h>
#endif

#ifdef	HAVE_SYS_SOCKET_H
#include <sys/socket.h>
#endif

#include <ctype.h>
#include <errno.h>

#ifdef	HAVE_LIMITS_H
#include <limits.h>
#endif

#include <signal.h>
#include <stdio.h>

#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif

#ifdef	HAVE_ALLOCA_H
#include <alloca.h>
#endif

#ifdef	HAVE_FCNTL_H
#include <fcntl.h>
#endif

#ifdef	STDC_HEADERS
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#endif

#ifdef	HAVE_UNISTD_H
#include <unistd.h>
#endif

#ifdef HAVE_DIRENT_H
# include <dirent.h>
# define NAMLEN(dirent)	strlen((dirent)->d_name)
#else
# define dirent direct
# define NAMLEN(dirent)	(dirent)->d_namlen
# if HAVE_SYS_NDIR_H
#  include <sys/ndir.h>
# endif
# if HAVE_SYS_DIR_H
#  include <sys/dir.h>
# endif
# if HAVE_NDIR_H
#  include <ndir.h>
# endif
#endif

#ifdef	HAVE_FTW_H
#include <ftw.h>
#endif

#ifdef	HAVE_PATHS_H
#include <paths.h>
#endif

#ifdef	HAVE_SYS_FILE_H
#include <sys/file.h>
#endif

#ifdef	HAVE_SYS_UTSNAME_H
#include <sys/utsname.h>
#endif

#ifdef	HAVE_SYS_WAIT_H
#include <sys/wait.h>
#endif

#ifdef	HAVE_ASM_BYTEORDER_H
#include <asm/byteorder.h>
#endif
#ifdef	HAVE_SYS_BYTEORDER_H
#include <sys/byteorder.h>
#endif
#ifdef	HAVE_ENDIAN_H
#include <endian.h>
#endif

#ifdef	HAVE_MALLOC_H
#include <malloc.h>
#else
#ifndef	__linux__
#error malloc definition needed for non Linux OS
#endif
#endif

#if !defined(HAVE_BCOPY)
# if defined(HAVE_MEMCPY)
#  define bcopy(_s, _d, _l)	memcpy((_d), (_s), (_l))
# endif
#endif

#if !defined(HAVE_BZERO)
# if defined(HAVE_MEMSET)
#  define bzero(_s, _l)		memset((_s), 0, (_l))
# endif
#endif
